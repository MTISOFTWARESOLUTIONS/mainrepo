#!/usr/bin/env python
# coding: UTF-8
class tragtorLang:
    
    language = "it"

### ERRORS

    error_in_file_single = """Errore all'apertura!\nDesideri avere più informazioni?"""
    
    error_in_file_multi = """Mentre si apriva, %i si sono verificati errori!\nDesideri avere più informazioni?"""
    
    error_in_file_not_accessible = """### ERRORE - NON ACCESSIBILE ###:
    
Il file '%s' non è leggibile."""
    
    error_in_file_not_accessible_explain = """Assicurati di aver scelto un file valido\ne di avere i diritti per accedere al file.
    
    Qualche volta questo errore è dovuto a file da zero-byte."""
    
    error_in_file_not_readable = """### ERRORE - NON LEGGIBILE ###:
    
IL file '%s' non è processabile. Non puoi procedere con un file illeggibile."""
    
    error_in_file_not_readable_explain = """### INFO - NON LEGGIBILE ###:
    
    Sei sicuro di avere i codec adatti installati?
    Dipende dal modo in cui hai compilato ffmpeg, potrebbe essere
    un problema di opzioni di compilazione mancanti.
    
    Molte versioni di UBUNTU per esempio mancano del supporto mp3 in ffmpeg.
    Per correggere il problema devi a) compilare autonomamente i sorgenti di ffmpeg
    o b) per UBUNTU - installare i pacchetti dai repositories medibuntu
    attraverso la funzione 'forza versione' in synaptics.
    Più informazioni sono disponibili:
    
    https://help.ubuntu.com/community/Medibuntu
    http://ffmpeg.mplayerhq.hu/
    http://wiki.ubuntuusers.de/FFmpeg (German)
    http://www.google.com/search?q=ffmpeg"""
    
    ffmpeg_options = """### Configurazione FFMPEG
    
# Sotto le tue attuali opzioni di compilazione di ffmpeg:
    %s

# Formati leggibili:
    %s
    
# Formati scrivibili:
    %s

# Codec audio leggibili:
    %s
    
# Codec audio scrivibili:
    %s

# Codec video leggibili:
    %s

# Codec video scrivibili:
    %s
"""
    error_message_title = "Errore!"
    error_message_file_not_readable = "Il file sorgente specificato non è leggibile!"
    error_message_file_not_in_media = "Il file sorgente specificato non è un file Media importabile!"
    error_message_file_not_writable = "Il file di destinazione specificato non è scrivibile!"
    error_message_file_not_out_media = "Il file di destinazione specificato non è un file Media esportabile!"
    error_message_no_opener = "Il file non può essere aperto perchè nè gnome-open\nnè kde-open sembrano essere installati."
    error_message_no_audio = "Nessun stream audio presente"
    error_message_no_video = "Nessun stream video presente"
    
    error_message_delete_failed = """Il file non può essere cancellato.
Hai i permessi richiesti?"""
    error_message_no_manual = "Nessuna voce manuale per FFmpeg disponibile."
    
    error_button_not_in_media = "Nessuna fonte processabile"
    error_button_not_writable = "La destinazione non è scrivibile"
    error_button_not_out_media = "La destinazione non è un file processabile"
    error_button_in_as_out = "Destinazione e fonte sono lo stesso file"
    error_button_duration = "Le tue impostazioni di tempo sono errate"
    error_button_size = "Vuoi creare uno video di dimensione 0?"
    error_button_bitrate = "Il valore della frequenza bits non è valido"
    error_button_frame_rate = "Il valore della frequenza fotogrammi non è valido"
    error_button_sample_rate = "Il valore della frequenza di campionamento non è valido"
    error_button_channels = "Il valore dei canali audio non è valido"
    error_button_no_audio = "Vuoi creare un file audio senza audio"
    error_button_no_content = "Vuoi creare un file senza contenuto"
    error_button_no_audio_bitrate = "Vuoi creare un file audio da 0 kb/s"
    error_button_no_video_bitrate = "Vuoi creare un file video da 0 kb/s"
    
    error_cant_proceed = "Non puoi proseguire con queste impostazioni."
        
### BUTTONS

    proceed_button_active = "Mostrami la luce!"
    proceed_button_overwrite = "Vuoi eseguire il processo di nuovo?\nIl file verrà sovrascritto"
    proceed_button_inactive = "Impossibile procedere:\n%s"
    
### INFILE TEXTAREA

    in_file_textarea_pre = """### Informazioni sul File Sorgente:
"""
    in_file_textarea_post = ""
    in_file_format_info = """
    File: %s
    Dimensione: %sBytes
    Contenitore: %s
    Frequenza Bits: %s k/bs
    Durata: %s
"""
    in_file_stream_main_info = """
    Stream-ID: %s
    Formato: %s
    Codec: %s
"""    
    in_file_stream_audio_info = """    Campionamento: %s hz
    Canali: %s
    Frequenza Bits Audio: %s kb/s
"""
    in_file_stream_video_info = """    Metodo: %s
    Dimensione: %s
    FPS: %s fps
"""

### INFILE

    in_file_audio_label = "Stream Audio"
    in_file_video_label = "Stream Video"
    in_file_open_label = "file selezionati"
    in_file_add_label = "Multi"
    in_file_select_label = "Singolo"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "File"
    in_file_open_size = "Dimensione"
    in_file_open_container = "Formato"
    in_file_open_duration = "Durata"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "Campionamento"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Canali"
    in_file_audio_language = "Lingua"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_codec = "Codec"
    in_file_video_size = "Dimensione"
    in_file_video_fps = "FPS"
    in_file_video_method = "Metodo"
    in_file_video_language = "Lingua"
    
    in_file_menu_path = "Stesso percorso per l'output"
    in_file_menu_name = "Stesso nome per l'output"
    in_file_menu_meta = "Adotta ID3"
    
### META COMMENT
    
    meta_comment_text = """Encoder ffmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Conferma"
    question_overwrite_preset = "Vuoi veramente sovrascrivere %s?"
    question_delete_preset = "Vuoi veramente cancellare %s?"
    question_delete_in_file = "Vuoi veramente cancellare il file #%i dal disco?\n (Non si potrà tornare indietro!)"

### TEXTLABELS

    # page-labels
    in_file_label = """Per prima cosa scegli
un file da convertire.

L'audio incluso e
lo stream video appariranno
sulla destra per la selezione.

Usa il bottone "Singolo"
per lavorare con un solo file.

Usa il bottone "Multi"
per lavorare con più file.

Clicca col tasto destro
un file per visualizzare
un menù opzioni."""

    suffix_label = "Contenitore:"

    meta_label = """Edita i Metadati
per il file finale.

Le informazioni immagazzinate
non influenzeranno nessun
valore relativo al file.

Alcuni formati possono
non supportare questa
operazione!"""

    proceed_label = """Continuare con la configurazione.

Il bottone grande ti informerà su come procedono le cose.

Dopo avre premuto il bottone per procedere\nverrà mostrata una finestra di conferma.

L'output di FFmpeg è visualizzato sulla destra."""
    format_video_label = "Impostazioni video"
    format_audio_label = "Impostazioni audio"
    format_render_label = "Impostazioni di rendering"
    format_results_label = "Risultati"
    settings_label = """Settaggi di base per la GUI"""
    
### NOTEBOOKS

    in_file_notebook = "Fonti"
    format_notebook = "Formato"
    meta_notebook = "Metadati"
    proceed_notebook = "Procedi"
    settings_notebook = "Impostazioni"

### TITOLS

    in_file_title = "Scegli la fonte"
    format_title = "Imposta il formato"
    meta_title = "Cambia metadati"
    proceed_title = "Procedi"
    settings_title = "Impostazioni"

### INPUT_VALUES

    meta_title_label = "Titolo:"
    meta_author_label = "Autore:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Commento:"
    meta_toggle_label = "Usa metadati"
    
    format_width_label = "Larghezza:"
    format_height_label = "Altezza:"
    format_ratio_label = "Frequenza:"
    format_fixed_ratio_label = "Rapporto fisso:"
    format_frame_rate_label = "Frequenza fotogrammi (s):"
    format_deinterlace_label = "Deinterlacciamento:"
    
    format_audio_sample_rate_label = "Campionamento:"
    format_audio_bitrate_label = "Frequenza Bits (kb/s):"
    format_audio_codec_label = "Forza codec:"
    format_audio_channels_label = "Canali audio:"
    format_2_pass_label = "2-passaggi:"
    format_2_pass_no_audio_label = "Elimina audio:"
    format_codec_label = "Forza codec:"
    format_bitrate_label = "Frequenza Bits (kb/s):"
    format_offset_label = "Inizio Offset (s):"
    format_duration_label = "Durata (s):"
    format_scaling_label = "Scaling:"
    format_pad_color_label = "Colore riempimento:"
    format_volume_label = "Volume:"
    format_user_defined_label = "Opzioni Addizionali:"
    format_manual_button = "Manuale FFmpeg"
    
    format_tooltip_changed = "Reset to %s"
    
### PRESETS
    
    presets_label = "Preimpostazioni"
    presets_container = """Imposta il contenitore
del file di output"""

### FORMAT-INFO
    
    format_target_info_av = """Un file video che include suono e video \
sarà lungo <b>%s</b> e occuperà <b>%sBytes</b> di spazio."""
    format_target_info_video = """Contenuto video puro senza nessun stream audio \
e la lunghezza di <b>%s</b> occuperà circa <b>%sBytes</b>."""
    format_target_info_audio = """Un file audio puro di  \
<b>%s</b> occuperà <b>%s</b> con queste impostazioni."""
    format_target_info = """%s<small>

(La dimensione risultante può essere diversa)</small>"""
    format_target_info_nothing = """Devi attivare almeno uno \
degli streams (audio o video)."""
    format_target_no_file = "Non hai scelto nessun file valido."
    
### OUTPUT/PROCEED

    proceed_folder_label = """Percorso"""
    proceed_suffix_label = """Contenitore"""
    proceed_name_label = """Nome"""
    
    frame_output = """Destinazione"""
    frame_proceed = """Procedi"""
    
    out_file_menu_path = "Stesso percorso della fonte"
    out_file_menu_name = "Stesso nome della fonte"
    
### SETTINGS
    
    settings_language_label ="Scegli la tua lingua"
    settings_reset_label = "Resetta tutti i valori e\ninizia con quelli di default"
    settings_reset_button = "Resetta"
    settings_video_filter_label = "Seleziona le tue opzioni pad e crop"
    settings_bitrate_mode_label = "Seleziona le tue opzioni bitrate"
    settings_cpu_label = "Uso CPU"
    settings_progress_actions = "Azione dopo l'elaborazione"
    settings_cleanup_2_pass_label = "Rimuovi Log dopo 2-Passaggi"
    settings_ffmpeg_label = "FFmpeg"
    settings_tragtor_label = "traGtor"
    settings_stream_label = "Selezionare il Separatore Stream\n(.) se usi avconv, (:) se usi ffmpeg"
    settings_version_label = "Informazioni su FFmpeg e traGtor"
    settings_newstream_label = "Use \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Pad", "Crop", "Distorto" ]
    output_file_suffix_auto = "Come mostrato sotto"
    cpu_usage_modes = ["Leggero", "Medio", "Aggressivo"]
    video_filters = ["Pad, Crop & Size (Vecchio)",
                     "Filtro Video (x:y:w:h)",
                     "Filtro Video (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (Vecchio)",
                     "-b:v / -b:a (Nuovo)"]
    progress_actions = ["Non fare nulla", "Avvia File", "Chiudi finestra di elaborazione", "Chiudi traGtor", "Spegni PC", "Iberna PC", "Sospendi PC"]
    stream_separators = [".", ":"]
    
### SYSTEM
    
    datestring = "%Y-%m-%d %I:%M:%S %p"
    hour = "ora"
    hours = "ore"
    minute = "minuto"
    minutes = "minuti"
    second = "secondo"
    seconds = "secondi"
    frames = "fotogrammi"
    _and = "e"
    
    changed = "cambiato!"
    
    title_in_file_media_files = "Mediafile leggibile"
    title_in_file_all_files = "Tutti i formati file"
    title_out_file_media_files = "Mediafile scrivibile"
    title_out_file_all_files = "Tutti i formati file"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Conferma"
    label_confirmation = """Controlla le tue impostazioni \
sulla destra. Puoi fare alcuni cambiamenti nella \
linea di comando per ffmpeg."""
    label_confirm_commandline = "Linea di comando"
    label_confirm_in_file = "<b>Fonte:</b> %s"
    label_confirm_in_files = "<b>Fonti:</b> %s"
    label_confirm_out_file = "<b>Destinazione:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Pad:</b> aggiungi %i pixel alla larghezza"
    label_confirm_pad_v = "<b>Pad:</b> aggiungi %i pixel all'altezza"
    label_confirm_crop_h = "<b>Crop:</b> taglia %i pixel dalla larghezza"
    label_confirm_crop_v = "<b>Crop:</b> taglia %i pixel dall'altezza"
    label_confirm_distort_h = "<b>Scaling:</b> adatta larghezza a %i\%"
    label_confirm_distort_v = "<b>Scaling:</b> adatta altezza a %i\%"
    label_confirm_format = "<b>Formato:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "disattivato"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Durata:</b> %s"
    label_confirm_offset = "<b>Inizio:</b> %s"
    label_confirm_size = "<b>Dimensione:</b> %s"

### PROCESS

    title_progress_window = "In avanzamento..."
    title_progress_window_finished = "Finito."
    title_progress_window_error = "Errore!"
    title_progress_window_pass = "(passaggio %i)"
    label_progress = "Il file è in elaborazione..."
    text_progress = "Stato del file\n%s"

    label_progress_size = "<b>Dimensione</b>"
    label_progress_bitrate = "<b>Frequenza Bits</b>"
    label_progress_time = "<b>Tempo</b>"
    label_progress_frame = "<b>Frame</b>"
    label_progress_quantizer = "<b>Quantizzatore</b>"
    label_progress_video = "<b>Video</b>"
    label_progress_audio = "<b>Audio</b>"
    label_progress_headers = "<b>Headers</b>"
    label_progress_overhead = "<b>Overhead</b>"
    
    label_progress_error = "<b>Errore!</b>"
    label_progress_error_explain = "Sembra sia avvenuto un errore. \
Fai riferimento all'area di testo dell'output di ffmpeg."
    label_progress_actions = "Fine"


### HELP-WINDOW

    title_help_window = "Aiuto"
    
### UOE window
    
    label_pass_1 = "Passaggio 1"
    label_pass_2 = "Passaggio 2"
    label_single = "Opzioni"
    label_UOE = """Modifica le tue impostazioni utente
qui. Non usare nessun a
capo. Se hai i
2 passaggi abilitati, entrambi
i campi verranno concatenati
con un simbolo pipe | nel
campo delle opzioni."""
