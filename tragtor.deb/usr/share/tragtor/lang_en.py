#!/usr/bin/env python
# coding: UTF-8
class tragtorLang:
    
    language = "en"

### ERRORS

    error_in_file_single = """An error occurred on opening!\n\nCare to see more information?"""

    error_in_file_multi = """While opening, %i errors occurred!\n\nCare to see more information?"""

    error_in_file_not_accessible = """### ERROR - NOT ACCESSIBLE ###: 

The file '%s' is not readable.""" 

    error_in_file_not_accessible_explain = """Please choose a correct working media file and make sure you have the proper rights to access it.

Sometimes this error may occur due to a zero-byte file."""

    error_in_file_not_readable = """### ERROR - NOT READABLE ###:

The file '%s' is not processable. You can't proceed with an unreadable file."""
    
    error_in_file_not_readable_explain = """### INFO - NOT READABLE ###:
    
Are you sure you have all the required codecs installed?

Depending on how you've compiled FFmpeg, it may also be a problem with missing compiler-options.
    
    Most versions of Ubuntu as an example are missing mp3 support in FFmpeg.
    To deal with it you have to A) compile the source of FFmpeg yourself
    or B) install the packages from the medibuntu-repositories through the
    'force version' function in Synaptics. More information is available:
    
    https://help.ubuntu.com/community/Medibuntu
    http://ffmpeg.mplayerhq.hu/
    http://wiki.ubuntuusers.de/FFmpeg (German)
    http://www.google.com/search?q=ffmpeg"""
    
    ffmpeg_options = """### FFMPEG-Configuration
    
# Your actual compile options of FFmpeg below:
    %s

# Readable file formats:
    %s
    
# Writable file formats:
    %s

# Readable audio-codecs:
    %s
    
# Writable audio-codecs:
    %s

# Readable video-codecs:
    %s

# Writable video-codecs:
    %s
"""
    error_message_title = "Error!"
    error_message_file_not_readable = "The source file you've specified is not readable!"
    error_message_file_not_in_media = "The source file you've specified is not importable!"
    error_message_file_not_writable = "The target file you've specified is not writable!"
    error_message_file_not_out_media = "The target file you've specified is not exportable!"
    error_message_no_opener = "The file can't be opened because neither gnome-open or kde-open seems to be installed."
    error_message_no_audio = "No audio streams present"
    error_message_no_video = "No video streams present"
    
    error_message_delete_failed = """The file can't be deleted.
Do you have the proper permissions?"""
    error_message_no_manual = "No manual entry for FFmpeg available."
    
    error_button_not_in_media = "No Processable Source"
    error_button_not_writable = "The Target Is Not Writable"
    error_button_not_out_media = "The Target Is Not Processable"
    error_button_in_as_out = "Target And Source Are The Same File"
    error_button_duration = "Your Time Settings Are Buggy"
    error_button_size = "You Want To Create A 0-Size Video?"
    error_button_bitrate = "The Value Of The Bitrate Is Invalid"
    error_button_frame_rate = "The Value Of The Frame Rate Is Invalid"
    error_button_sample_rate = "The Value Of The Sample Rate Is Invalid"
    error_button_channels = "The Value Of The Audio Channels Is Invalid"
    error_button_no_audio = "You Want To Create An Audio File Without Audio?"
    error_button_no_content = "You Want To Create A File Without Any Content?"
    error_button_no_audio_bitrate = "You Want To Create A 0 kb/s Audio File?"
    error_button_no_video_bitrate = "You Want To Create A 0 kb/s Video File?"
    
    error_cant_proceed = "You Can't Go On With These Settings."
        
### BUTTONS

    proceed_button_active = "Show Me The Light!"
    proceed_button_overwrite = "Would You Like To Process Again?\nThe File Will Be Overwritten"
    proceed_button_inactive = "Proceeding Impossible\n%s"
    
### IN FILE TEXT AREA

    in_file_text_area_pre = """### Information about Source-File:
"""
    in_file_text_area_post = ""
    in_file_format_info = """
    File: %s
    Size: %sBytes
    Container: %s
    Bitrate: %s k/bs
    Duration: %s
"""
    in_file_stream_main_info = """
    Stream-ID: %s
    Format: %s
    Codec: %s
"""    
    in_file_stream_audio_info = """    Sample_Rate: %s hz
    Channels: %s
    Audio-Bitrate: %s kb/s
"""
    in_file_stream_video_info = """    Method: %s
    Size: %s
    FPS: %s fps
"""

### IN FILE

    in_file_audio_label = "Audio Streams"
    in_file_video_label = "Video Streams"
    in_file_open_label = "Selected Files"
    in_file_add_label = "Multi"
    in_file_select_label = "Single"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "File"
    in_file_open_size = "Size"
    in_file_open_container = "Format"
    in_file_open_duration = "Duration"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "Sample Rate"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Channels"
    in_file_audio_language = "Language"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_codec = "Codec"
    in_file_video_size = "Size"
    in_file_video_fps = "FPS"
    in_file_video_method = "Method"
    in_file_video_language = "Language"
    
    in_file_menu_path = "Path as output"
    in_file_menu_name = "Name as output"
    in_file_menu_meta = "Adopt ID3"
    
### META COMMENT
    
    meta_comment_text = """Encoder FFmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Confirmation"
    question_overwrite_preset = "Do you really want to overwrite %s?"
    question_delete_preset = "Do you really want to delete %s?"
    question_delete_in_file = "Do you really want to delete the file #%i from disk?"

### TEXT LABELS

    # page-labels
    in_file_label = """First Please Select The 
File(s) You'd Like To Convert

The Included Audio And 
Video Streams Will Appear 
On The Right For Selection
    
Use The "Single" Button 
To Work With A Single File

Use The "Multi" Button 
To Work With Several Files

Right Click A File 
To Get Menu Options"""

    suffix_label = "Container:"

    meta_label = """Edit The Metadata 
For The Final Media File

Information Stored Does
Not Affect Any File-Related
Values Like The File Name

Some Formats May Not
Support This!"""

    proceed_label = """Click Below To Proceed

The Button Will Inform You About Many Things

Active Media Shows A Confirmation Window Right After You Click The Process Button 

Output For FFmpeg Is Shown On The Right"""

    format_video_label = "Video Settings"
    format_audio_label = "Audio Settings"
    format_render_label = "Render Settings"
    format_results_label = "Results"
    settings_label = """Basic GUI Settings"""
    
### NOTEBOOKS

    in_file_notebook = "Sources"
    format_notebook = "Format"
    meta_notebook = "Meta"
    proceed_notebook = "Proceed"
    settings_notebook = "Settings"

### TITLES

    in_file_title = "Choose Source"
    format_title = "Set Format"
    meta_title = "Change Meta"
    proceed_title = "Proceed"
    settings_title = "Settings"

### INPUT_VALUES

    meta_title_label = "Title:"
    meta_author_label = "Author:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Comment:"
    meta_toggle_label = "Use Meta"
    
    format_width_label = "Width:"
    format_height_label = "Height:"
    format_ratio_label = "Ratio:"
    format_fixed_ratio_label = "Fixed Ratio:"
    format_frame_rate_label = "Frame Rate / s:"
    format_deinterlace_label = "Deinterlace:"
    
    format_audio_sample_rate_label = "Sample Rate:"
    format_audio_bitrate_label = "Bitrate (kb/s):"
    format_audio_codec_label = "Force Codec:"
    format_audio_channels_label = "Audio Channels:"
    format_2_pass_label = "2-Pass:"
    format_2_pass_no_audio_label = "Skip Audio:"
    format_codec_label = "Force Codec:"
    format_bitrate_label = "Bitrate (kb/s):"
    format_offset_label = "Start Offset / s:"
    format_duration_label = "Duration / s:"
    format_scaling_label = "Scaling:"
    format_pad_color_label = "Padding Color:"
    format_volume_label = "Volume:"
    format_user_defined_label = "Additional Options:"
    format_manual_button = "FFmpeg Manual"
    
    format_tooltip_changed = "Reset to %s"
    
### PRESETS
    
    presets_label = "Presets"
    presets_container = """Set Container
Of Output File"""

### FORMAT-INFO
    
    format_target_info_av = """<b>%s - %sBytes</b>"""

    format_target_info_video = """Video Content Without Audio Stream: \
<b>%s</b> - <b>%sBytes</b>."""

    format_target_info_audio = """<b>%s - %sBytes</b>"""

    format_target_info = """%s<small>

(The resulting size may differ)</small>"""
    format_target_info_nothing = """You Have To Activate At Least One \
Of The Streams (Audio Or Video)."""
    format_target_no_file = "<b>No Valid Files Selected!</b>"

### OUTPUT/PROCEED

    proceed_folder_label = """Folder"""
    proceed_suffix_label = """Container"""
    proceed_name_label = """Name"""
    
    frame_output = """Output"""
    frame_proceed = """Proceed"""
    
    out_file_menu_path = "Path From Source"
    out_file_menu_name = "Name From Source"
    
### SETTINGS
    
    settings_language_label ="Choose Your Language"
    settings_reset_label = "Reset All Values To Default And Start All Over"
    settings_reset_button = "Reset"
    settings_video_filter_label = "Select Your Pad And Crop Option"
    settings_bitrate_mode_label = "Select Bitrate Option"
    settings_cpu_label = "CPU Usage"
    settings_progress_actions = "Action After Progress"
    settings_cleanup_2_pass_label = "Remove Log After 2-Pass"
    settings_ffmpeg_label = "FFmpeg:"
    settings_tragtor_label = "traGtor:"
    settings_version_label = "Information About FFmpeg And traGtor"
    settings_stream_label = "Select Stream Separator\n(.) if use avconv, (:) if use ffmpeg"
    settings_newstream_label = "Use \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Pad", "Crop", "Distort" ]
    output_file_suffix_auto = "as stated below"
    cpu_usage_modes = ["Soft", "Medium", "Aggressive"]
    video_filters = ["Pad, Crop & Size (Old)",
                     "Video Filter (x:y:w:h)",
                     "Video Filter (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (old)",
                     "-b:v / -b:a (new)"]
    progress_actions = ["Nothing", "Play File", "Close Progress Window",
                     "Close traGtor", "Shutdown", "Hibernate",
                     "Suspend"]
    stream_separators = [".", ":"]
                     
### SYSTEM
    
    date_string = "%Y-%m-%d %I:%M:%S %p"
    hour = "hour"
    hours = "hours"
    minute = "minute"
    minutes = "minutes"
    second = "second"
    seconds = "seconds"
    frames = "frames"
    _and = "and"
    
    changed = "changed!"
    
    title_in_file_media_files = "Readable Media Files"
    title_in_file_all_files = "All File Formats"
    title_out_file_media_files = "Writable Media Files"
    title_out_file_all_files = "All File Formats"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Confirmation"
    label_confirmation = """Confirm Your Settings On The Right

You Can Make Some Changes On The Commandline"""
    label_confirm_commandline = "Commandline"
    label_confirm_in_file = "<b>Source:</b> %s"
    label_confirm_in_files = "<b>Sources:</b> %s"
    label_confirm_out_file = "<b>Target:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Pad:</b> adding %i pixel to width"
    label_confirm_pad_v = "<b>Pad:</b> adding %i pixel to height"
    label_confirm_crop_h = "<b>Crop:</b> ripping %i pixel from width"
    label_confirm_crop_v = "<b>Crop:</b> ripping %i pixel from height"
    label_confirm_distort_h = "<b>Scaling:</b> stretching width to %i\%"
    label_confirm_distort_v = "<b>Scaling:</b> stretching height to %i\%"
    label_confirm_format = "<b>Format:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "deactivated"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Duration:</b> %s"
    label_confirm_offset = "<b>Start:</b> %s"
    label_confirm_size = "<b>Size:</b> %s"

### PROCESS

    title_progress_window = "In Progress..."
    title_progress_window_finished = "Finished."
    title_progress_window_error = "Error!"
    title_progress_window_pass = "(pass %i)"
    label_progress = "Processing..."
    text_progress = "Status of file\n%s"

    label_progress_size = "<b>Size:</b>"
    label_progress_bitrate = "<b>Bitrate:</b>"
    label_progress_time = "<b>Time:</b>"
    label_progress_frame = "<b>Frame:</b>"
    label_progress_quantizer = "<b>Quantizer:</b>"
    label_progress_video = "<b>Video:</b>"
    label_progress_audio = "<b>Audio:</b>"
    label_progress_headers = "<b>Headers:</b>"
    label_progress_overhead = "<b>Overhead:</b>"
    
    label_progress_error = "<b>Error!</b>"
    label_progress_error_explain = "It seems that an error occurred. \
Please refer to the text area for FFmpeg's output."
    label_progress_actions = "Finally"

### HELP-WINDOW

    title_help_window = "Help"
    
### UOE window
    
    label_pass_1 = "Pass 1"
    label_pass_2 = "Pass 2"
    label_single = "Options"
    label_UOE = """Edit Your User Options
Here. Don't Use Any Line
Breaks. If You Have
2 Pass Enabled Both
Fields Will Be Concatenated
With A Pipe Symbol | In
The Options Field."""
