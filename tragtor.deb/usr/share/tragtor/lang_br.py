#!/usr/bin/env python
# coding: UTF-8
class tragtorLang:
    
    language = "br"

### ERRORS

    error_in_file_single = """Um erro ocorreu ao abrir!\n\nDeseja ver mais imformações?"""

    error_in_file_multi = """Ao abrir, %i erros ocorrerão!\n\nDeseja ver mais imformações?"""

    error_in_file_not_accessible = """### ERRO - NÃO ACESSÍVEL ###: 

O arquivo '%s' não é ligível.""" 

    error_in_file_not_accessible_explain = """Por favor, escolha um arquivo de mídia correto e verifique se você tem os direitos apropriados para acessá-lo.

Às vezes, esse erro pode ocorrer devido a um arquivo de zero bytes."""

    error_in_file_not_readable = """### ERRO - NÃO ACESSÍVEL ###:

O arquivo '%s' não é processável. Você não pode continuar com um arquivo ilegível."""
    
    error_in_file_not_readable_explain = """### INFO - NÃO PODE SER LIDO ###:
    
Tem certeza de que você tem todos os codecs necessários instalados??

Dependendo de como você compilou FFmpeg, ele também pode ser um problema com a falta de opções do compilador.
    
    A maioria das versões do Ubuntu como um exemplo está faltando apoio mp3 em FFmpeg.
     Para lidar com isso você tem que A) compilar o código fonte do FFmpeg
     ou B) instalar os pacotes a partir dos repositórios Medibuntu-através da
     função 'force version' em Synaptics. Mais informações estão disponíveis:
    
    https://help.ubuntu.com/community/Medibuntu
    http://ffmpeg.mplayerhq.hu/
    http://wiki.ubuntuusers.de/FFmpeg (German)
    http://www.google.com/search?q=ffmpeg"""
    
    ffmpeg_options = """### FFMPEG-Configuração
    
# Suas opções de compilação reais de FFmpeg abaixo:
    %s

# Formatos de arquivos legíveis:
    %s
    
# Formatos de arquivos graváveis:
    %s

# Audio-codecs legíveis:
    %s
    
# Audio-codecs graváveis:
    %s

# Video-codecs legíveis:
    %s

# Video-codecs graváveis:
    %s
"""
    error_message_title = "Erro!"
    error_message_file_not_readable = "O arquivo de origem que você especificou não é legível!"
    error_message_file_not_in_media = "O arquivo de origem que você especificou não pode ser importado!"
    error_message_file_not_writable = "O arquivo de destino que você especificou não é gravável!"
    error_message_file_not_out_media = "O arquivo de destino que você especificou não é exportável!"
    error_message_no_opener = "O arquivo não pode ser aberto porque gnome-open ou kde-open parece estar instalado."
    error_message_no_audio = "Não há áudio"
    error_message_no_video = "Nenhum há vídeo de streams"
    
    error_message_delete_failed = """O arquivo não pode ser excluído..
Você tem as permissões necessárias?"""
    error_message_no_manual = "Nenhuma entrada de manual para FFmpeg disponível."
    
    error_button_not_in_media = "Nenhuma fonte processável"
    error_button_not_writable = "O alvo não é gravável"
    error_button_not_out_media = "O alvo não é processável"
    error_button_in_as_out = "Origem e destino são o mesmo arquivo"
    error_button_duration = "Suas configurações de tempo estão Buggy"
    error_button_size = "Você quer criar um 0-Size Vídeo?"
    error_button_bitrate = "O valor da taxa de bits é inválido"
    error_button_frame_rate = "O valor da taxa de quadros é inválido"
    error_button_sample_rate = "O valor da taxa de amostragem é inválido"
    error_button_channels = "O valor dos canais de áudio é inválido"
    error_button_no_audio = "Você deseja criar um arquivo de áudio sem som?"
    error_button_no_content = "Você quer criar um arquivo sem nenhum conteúdo?"
    error_button_no_audio_bitrate = "Você quer criar 0 kb/s de arquivos de audio?"
    error_button_no_video_bitrate = "Você quer criar 0 kb/s de arquivos de vídeo?"
    
    error_cant_proceed = "Você não pode continuar com essas configurações."
        
### BUTTONS

    proceed_button_active = "Mostre-me a luz!"
    proceed_button_overwrite = "Gostaria de processar novamente?\nO arquivo será sobrescrito"
    proceed_button_inactive = "Processamento impossível\n%s"
    
### IN FILE TEXT AREA

    in_file_text_area_pre = """### Informações sobre o Arquivo-Fonte:
"""
    in_file_text_area_post = ""
    in_file_format_info = """
    Arquivo: %s
    Tamanho: %sBytes
    Conteiner: %s
    Bitrate: %s k/bs
    Duração: %s
"""
    in_file_stream_main_info = """
    Stream-ID: %s
    Formato: %s
    Codec: %s
"""    
    in_file_stream_audio_info = """    Sample_Rate: %s hz
    Canais: %s
    Audio-Bitrate: %s kb/s
"""
    in_file_stream_video_info = """    Method: %s
    Tamanho: %s
    FPS: %s fps
"""

### IN FILE

    in_file_audio_label = "Streams de áudio"
    in_file_video_label = "Streams de vídeo"
    in_file_open_label = "Arquivos selecionados"
    in_file_add_label = "Multiplo"
    in_file_select_label = "Único"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "Arquivo"
    in_file_open_size = "Tamanho"
    in_file_open_container = "Formato"
    in_file_open_duration = "Duração"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "Taxa de amostragem"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Canais"
    in_file_audio_language = "Linguagem"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_codec = "Codec"
    in_file_video_size = "Tamanho"
    in_file_video_fps = "FPS"
    in_file_video_method = "Método"
    in_file_video_language = "Linguagem"
    
    in_file_menu_path = "Caminho de saída"
    in_file_menu_name = "Nome de saída"
    in_file_menu_meta = "Adopt ID3"
    
### META COMMENT
    
    meta_comment_text = """Encoder FFmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Confirmação"
    question_overwrite_preset = "Você realmente deseja substituir %s?"
    question_delete_preset = "Você realmente deseja deletar %s?"
    question_delete_in_file = "Você realmente deseja excluir o arquivo #%i do disco?"

### TEXT LABELS

    # page-labels
    in_file_label = """Primeiro selecione o 
Arquivo(s) que deseja converter

O áudio incluído e
Streams de vídeo será apresentado
Na direita para Seleção
    
Use o botão "Único" 
Para trabalhar com um único arquivo

Use o botão "Multiplo" 
Para trabalhar com vários arquivos

Clique no arquivo a direita 
Para obter opções de menu"""

    suffix_label = "Conteiner:"

    meta_label = """Edite os metadados 
Para o arquivo de mídia final

Informações armazenadas
Não afeta nenhum arquivo relacionado
Valores como o nome do arquivo

Alguns formatos pode não
Suportar isto!"""

    proceed_label = """Clique para continuar abaixo

O botão irá informá-lo sobre muitas coisas

Active Media Mostra uma janela de confirmação logo após clicar no botão Processo

Saída Para FFmpeg é mostrado à direita"""

    format_video_label = "Configurações de vídeo"
    format_audio_label = "Configurações de audio"
    format_render_label = "Configurações de Renderização"
    format_results_label = "Resultados"
    settings_label = """Basic GUI Settings"""
    
### NOTEBOOKS

    in_file_notebook = "Fonte"
    format_notebook = "Formato"
    meta_notebook = "Meta"
    proceed_notebook = "Prosseguir"
    settings_notebook = "Configurações"

### TITLES

    in_file_title = "Escolha a fonte"
    format_title = "Escolha o formato"
    meta_title = "Mude Meta"
    proceed_title = "Prosseguir"
    settings_title = "Configurações"

### INPUT_VALUES

    meta_title_label = "Título:"
    meta_author_label = "Autor:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Comentário:"
    meta_toggle_label = "Use Meta"
    
    format_width_label = "Width:"
    format_height_label = "Height:"
    format_ratio_label = "Ratio:"
    format_fixed_ratio_label = "Proporção fixa:"
    format_frame_rate_label = "Frame Rate / s:"
    format_deinterlace_label = "Desentrelaçamento:"
    
    format_audio_sample_rate_label = "Taxa de amostragem:"
    format_audio_bitrate_label = "Bitrate (kb/s):"
    format_audio_codec_label = "Forçar Codec:"
    format_audio_channels_label = "Canais de Audio:"
    format_2_pass_label = "2-Passos:"
    format_2_pass_no_audio_label = "Adiantar Audio:"
    format_codec_label = "Forçar Codec:"
    format_bitrate_label = "Bitrate (kb/s):"
    format_offset_label = "Iniciar Offset / s:"
    format_duration_label = "Duração / s:"
    format_scaling_label = "Scaling:"
    format_pad_color_label = "Padding Color:"
    format_volume_label = "Volume:"
    format_user_defined_label = "Opções Adicionais:"
    format_manual_button = "Manual FFmpeg"
    
    format_tooltip_changed = "Reset to %s"
    
### PRESETS
    
    presets_label = "Presets"
    presets_container = """definir Conteiner
Para saída do arquivo"""

### FORMAT-INFO
    
    format_target_info_av = """<b>%s - %sBytes</b>"""

    format_target_info_video = """Conteúdo do vídeo sem Stream de Audio: \
<b>%s</b> - <b>%sBytes</b>."""

    format_target_info_audio = """<b>%s - %sBytes</b>"""

    format_target_info = """%s<small>

(O tamanho resultante pode diferir)</small>"""
    format_target_info_nothing = """Você tem que ativar pelo menos um \
Dos fluxos (áudio ou vídeo)."""
    format_target_no_file = "<b>Nenhum arquivo válidos selecionados!</b>"

### OUTPUT/PROCEED

    proceed_folder_label = """Pasta"""
    proceed_suffix_label = """Conteiner"""
    proceed_name_label = """Nome"""
    
    frame_output = """Saída"""
    frame_proceed = """Prosseguir"""
    
    out_file_menu_path = "Caminho para a fonte"
    out_file_menu_name = "Nome da fonte"
    
### SETTINGS
    
    settings_language_label ="Escolha sua linguagem"
    settings_reset_label = "Ajustar todos os valores para padrão"
    settings_reset_button = "Resetar"
    settings_video_filter_label = "Selecione o seu bloco e opções de cortar"
    settings_bitrate_mode_label = "Selecione a opção de taxa"
    settings_cpu_label = "CPU Usada"
    settings_progress_actions = "Ação após o progresso"
    settings_cleanup_2_pass_label = "Remover log após 2-Passos"
    settings_ffmpeg_label = "FFmpeg:"
    settings_tragtor_label = "traGtor:"
    settings_version_label = "Informações sobre FFmpeg E traGtor"
    settings_stream_label = "Selecione o fluxo separador\n(.) se usar avconv, (:) ou usar ffmpeg"
    settings_newstream_label = "Use \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Bloco", "Cortar", "Distorcer" ]
    output_file_suffix_auto = "Como indicado abaixo"
    cpu_usage_modes = ["Suave", "Medio", "Agressivo"]
    video_filters = ["Bloco, Cortar & Tamanho (Old)",
                     "Video Filter (x:y:w:h)",
                     "Video Filter (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (old)",
                     "-b:v / -b:a (new)"]
    progress_actions = ["Nada", "Reproduzir arquivo", "Fechar janela de progresso",
                     "Fechar traGtor", "Desligar", "Hibernar",
                     "Suspender"]
    stream_separators = [".", ":"]
                     
### SYSTEM
    
    date_string = "%Y-%m-%d %I:%M:%S %p"
    hour = "hora"
    hours = "horas"
    minute = "minuto"
    minutes = "minutos"
    second = "segundo"
    seconds = "segundos"
    frames = "frames"
    _and = "e"
    
    changed = "Alterado!"
    
    title_in_file_media_files = "Arquivos de mídia legível"
    title_in_file_all_files = "Todos formatos de arquivo"
    title_out_file_media_files = "Arquivos de mídia graváveis"
    title_out_file_all_files = "Todos os formatos de arquivo"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Confirmação"
    label_confirmation = """Confirme suas configurações à direita

Você pode fazer algumas mudanças na linha de comando"""
    label_confirm_commandline = "Commandline"
    label_confirm_in_file = "<b>Fonte:</b> %s"
    label_confirm_in_files = "<b>Fontes:</b> %s"
    label_confirm_out_file = "<b>Alvo:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Bloco:</b> adding %i pixel to width"
    label_confirm_pad_v = "<b>Bloco:</b> adding %i pixel to height"
    label_confirm_crop_h = "<b>Cortar:</b> ripping %i pixel from width"
    label_confirm_crop_v = "<b>Cortar:</b> ripping %i pixel from height"
    label_confirm_distort_h = "<b>Escalamento:</b> stretching width to %i\%"
    label_confirm_distort_v = "<b>Escalamento:</b> stretching height to %i\%"
    label_confirm_format = "<b>Formato:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "desativado"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Duração:</b> %s"
    label_confirm_offset = "<b>Iniciar:</b> %s"
    label_confirm_size = "<b>Tamanho:</b> %s"

### PROCESS

    title_progress_window = "Em Progresso..."
    title_progress_window_finished = "Finalizado."
    title_progress_window_error = "Erro!"
    title_progress_window_pass = "(pass %i)"
    label_progress = "Processando..."
    text_progress = "Status do arquivo\n%s"

    label_progress_size = "<b>Tamanho:</b>"
    label_progress_bitrate = "<b>Bitrate:</b>"
    label_progress_time = "<b>Time:</b>"
    label_progress_frame = "<b>Frame:</b>"
    label_progress_quantizer = "<b>Quantizer:</b>"
    label_progress_video = "<b>Video:</b>"
    label_progress_audio = "<b>Audio:</b>"
    label_progress_headers = "<b>Headers:</b>"
    label_progress_overhead = "<b>Overhead:</b>"
    
    label_progress_error = "<b>Erro!</b>"
    label_progress_error_explain = "Parece que ocorreu um erro. \
Por favor, consulte a área de texto para a saída do FFmpeg."
    label_progress_actions = "Terminado"

### HELP-WINDOW

    title_help_window = "Ajuda"
    
### UOE window
    
    label_pass_1 = "Passo 1"
    label_pass_2 = "Passos 2"
    label_single = "Opções"
    label_UOE = """Edite suas opções de usuário
Aqui. Don't Use Any Line
Breaks. If You Have
2 Pass Enabled Both
Fields Will Be Concatenated
With A Pipe Symbol | In
The Options Field."""
