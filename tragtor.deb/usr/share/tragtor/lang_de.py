#!/usr/bin/env python
# coding: UTF-8
class tragtorLang:
    
    language = "de"
    
### ERRORS
    
    error_in_file_single = """Es ist ein Fehler aufgetreten!\nMöchtest Du weitere Informationen darüber?"""
    error_in_file_multi = """Es sind %i Fehler aufgetreten!\nMöchtest Du weitere Informationen darüber?"""
    
    error_in_file_not_accessible = """### FEHLER[not_accessible]:
    Die Datei '%s' kann nicht gelesen werden."""
    
    error_in_file_not_accessible_explain = """### INFO [not_accessible]:
    Stelle sicher, dass Du eine gültige Datei gewählt hast und Leserechte für die Datei besitzt.
    In seltenen Fällen kann der Grund auch eine Null-Bytes Datei sein.
"""

    error_in_file_not_readable = """### FEHLER [not_readable]:
    Die Datei '%s' kann nicht verarbeitet werden."""
    
    error_in_file_not_readable_explain = """### INFO [not_readable]:
    Hast Du alle nötigen Codecs installiert?
    Je nachdem, wie Du ffmpeg kompiliert hast, könnten dort auch einige Optionen fehlen.
    
    In UBUNTU beispielsweise haben die ffmpeg-Versionen regelmässig keinen MP3-Support.
    Um trotzdem mit diesen Formaten zu arbeiten, kannst Du Dir a) ffmpeg aus den Quellen
    selberkompilieren, oder b) auf UBUNTU-Systemen - die Medibuntuquellen einbinden
    und mit Hilfe der "Version erzwingen"-Funktion in Synaptic die ältere ffmpeg-Version
    installieren. Mehr Informationen:
    
    http://ffmpeg.mplayerhq.hu/ (Englisch)
    http://www.thedesignexperience.org/weblog/one-entry?entry_id=113488 (Englisch)
    http://wiki.ubuntuusers.de/FFmpeg
    
    und natürlich http://www.google.de/search?q=ffmpeg"""
    
    ffmpeg_options = """### FFMPEG-Konfiguration
    
# Deine aktuellen Optionen beim Kompilieren von ffmpeg:
    %s

# Lesbare Dateiformate:
    %s

# Schreibbare Dateiformate:
    %s

# Lesbare Audio-Codecs:
    %s
    
# Schreibbare Audio-Codecs:
    %s

# Lesbare Video-Codecs:
    %s

# Schreibbare Video-Codecs:
    %s
"""
    error_message_title = "Fehler!"
    error_message_file_not_readable = "Die angegebene Quelldatei ist nicht lesbar!"
    error_message_file_not_in_media = "Die angegebene Quelldatei ist keine importierbare Mediendatei!"
    error_message_file_not_writable = "Die angegebene Zieldatei ist nicht schreibbar!"
    error_message_file_not_out_media = "Die angegebene Zieldatei ist keine exportierbare Mediendatei!"
    error_message_no_opener = "Die Datei kann nicht geöffnet werden, da weder gnome-open noch kde-open installiert ist."
    error_message_no_audio = "Keine Audiostreams gefunden!"
    error_message_no_video = "Keine Videostreams gefunden!"
    
    error_message_delete_failed = """Die Datei konnte nicht gelöscht werden.
Besitzt Du die nötigen Zugriffsrechte?"""
    error_message_no_manual = "Kein Manual-Eintrag für FFmpeg gefunden."
    
    error_button_not_in_media = "Keine verwertbare Quelldatei"
    error_button_not_writable = "Die Zieldatei ist nicht schreibbar"
    error_button_not_out_media = "Die Zieldatei ist keine Mediendatei"
    error_button_in_as_out = "Die Zieldatei ist dieselbe, wie die Quelle"
    error_button_duration = "Die Zeitangaben sind nicht korrent"
    error_button_size = "Du willst ein Video mit 0 Pixeln Größe erstellen"
    error_button_bitrate = "Der Wert einer Bitrate ist ungültig"
    error_button_frame_rate = "Der Wert der Framerate ist ungültig"
    error_button_sample_rate = "Der Wert für die Samplerate ist ungültig"
    error_button_channels = "Der Wert für die Audiokanäle ist ungültig"
    error_button_no_audio = "Du willst eine Audiodatei ohne Audio erstellen"
    error_button_no_content = "Du willst eine Datei ohne Inhalt erstellen"
    error_button_no_audio_bitrate = "Du willst eine Audiodatei mit 0 kb/s erstellen"
    error_button_no_video_bitrate = "Du willst eine Videodatei mit 0 kb/s erstellen"
    
    error_cant_proceed = "Mit diesen Einstellungen kannst Du leider nicht fortfahren."
    
### BUTTONS

    proceed_button_active = "Zeig' mir das Licht!"
    proceed_button_overwrite = "Kann angehen, allerdings wird\ndie Datei überschrieben"
    proceed_button_inactive = "Noch geht nichts:\n%s"    

### INFILE TEXTAREA

    in_file_textarea_pre = """### Informationen über die Quell-Datei:
"""
    in_file_textarea_post = ""
    in_file_format_info = """
    Datei: %s
    Größe: %sBytes
    Container: %s
    Bitrate: %s k/bs
    Dauer: %s
"""
    in_file_stream_main_info = """
    Stream-ID: %s
    Format: %s
    Codec: %s
"""    
    in_file_stream_audio_info = """    Samplerate: %s hz
    Kanäle: %s
    Audio-Bitrate: %s kb/s
"""
    in_file_stream_video_info = """    Methode: %s
    Größe: %s
    FPS: %s fps
"""

### INFILE

    in_file_audio_label = "Audiostreams"
    in_file_video_label = "Videostreams"
    in_file_open_label = "gewählte Dateien"
    in_file_add_label = "Multi"
    in_file_select_label = "Single"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "Datei"
    in_file_open_size = "Größe"
    in_file_open_container = "Format"
    in_file_open_duration = "Dauer"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_language = "Sprachcode"
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "Samplerate"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Kanäle"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_language = "Sprachcode"
    in_file_video_codec = "Codec"
    in_file_video_size = "Größe"
    in_file_video_fps = "FPS"
    in_file_video_method = "Methode"
    
    in_file_menu_path = "Pfad als Ausgabe"
    in_file_menu_name = "Name als Ausgabe"
    in_file_menu_meta = "ID3 übernehmen"

### META COMMENT
    
    meta_comment_text = """Encoder ffmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Bestätigung"
    question_overwrite_preset = "Soll die Voreinstellung %s wirklich überschrieben werden?"
    question_delete_preset = "Soll die Voreinstellung %s wirklich gelöscht werden?"
    question_delete_in_file = "Soll die Datei #%i vom Datenträger gelöscht werden? (Kein Rückgängig!)"

### TEXTLABELS

    # page-labels
    in_file_label = """Zuerst musst Du eine \
Datei zum Konvertieren angeben. Wenn die Datei \
von ffmpeg gelesen werden kann, werden Dir rechts \
die enthaltenen Audio- und Videospuren zur Auswahl angezeigt. \
Ist "Multi" aktiv, werden gewählte Dateien zur Liste hinzugefügt, \
"Single" ersetzt die Liste mit der gewählten Datei. Ein Rechtsklick auf eine Datei bietet Dir verschiedene Optionen."""
    meta_label = """META-Informationen bearbeiten. \
Diese Daten werden in der Datei gespeichert und beeinflussen keine \
Dateiangaben, wie z.B. den Dateiamen (Einige Codecs unterstützen das nicht!)"""
    proceed_label = """Mit den Einstellungen Rendern. \
Der große Button informiert Dich über den Stand der Dinge. \
Ist er aktiv, wird Dir eine Bestätigung eingeblendet. \
Die Ausgabe von ffmpeg wird Dir in dem Bereich rechts angezeigt, \
sobald der Prozess beendet ist."""
    format_video_label = "Videoeinstellungen"
    format_audio_label = "Audioeinstellungen"
    format_render_label = "Rendereinstellungen"
    format_results_label = "Ergebnis"
    settings_label = """Hier kannst Du einige Grundeinstellungen für diese \
Oberfläche vornehmen."""
    
### NOTEBOOKS

    in_file_notebook = "Quelldateien"
    format_notebook = "Format"
    meta_notebook = "Meta"
    proceed_notebook = "Ausführen"
    settings_notebook = "Einstellungen"

### TITLES

    in_file_title = "Quelle wählen"
    format_title = "Formateinstellungen"
    meta_title = "Meta-Angaben"
    proceed_title = "Ausführen"
    settings_title = "Einstellungen"
        
### INPUT_VALUES

    meta_title_label = "Titel:"
    meta_author_label = "Autor:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Kommentar:"
    meta_toggle_label = "Aktivieren"
    
    format_width_label = "Breite:"
    format_height_label = "Höhe:"
    format_ratio_label = "Verhältnis:"
    format_fixed_ratio_label = "Festes Verh."
    format_frame_rate_label = "Bildrate / s:"
    format_deinterlace_label = "Deinterlace:"
    
    format_audio_sample_rate_label = "Samplerate:"
    format_audio_bitrate_label = "Bitrate (kb/s):"
    format_audio_codec_label = "Codec erzwingen:"
    format_audio_channels_label = "Audiokanäle:"
    format_2_pass_label = "2-Pass:"
    format_2_pass_no_audio_label = "Audio übergehen:"
    format_codec_label = "Codec erzwingen:"
    format_bitrate_label = "Bitrate (kb/s):"
    format_offset_label = "Start Offset / s:"
    format_duration_label = "Dauer / s:"
    format_scaling_label = "Skalierung:"
    format_pad_color_label = "Leerraum:"
    format_volume_label = "Lautstärke:"
    format_user_defined_label = "Eigene Optionen:"
    format_manual_button = "FFmpeg Hilfe"
    
    format_tooltip_changed = "Zurücksetzen auf %s"
    
### PRESETS
    
    presets_label = "Voreinstellungen"
    presets_container = """Containerformat der
Ausgabedatei setzen"""
    
### FORMAT-INFO
    
    format_target_info_av = """Eine Videodatei mit Bild und Ton \
wird <b>%s</b> lang sein und etwa <b>%sBytes</b> Speicher belegen."""
    format_target_info_video = """Als Video ohne Ton hat die Datei \
eine Länge von <b>%s</b> und die endgültige Größe von etwa <b>%sBytes</b>."""
    format_target_info_audio = """Eine reine Audiodatei von \
<b>%s</b> Länge ist mit diesen Einstellungen <b>%sBytes</b> groß."""
    format_target_info = """%s<small>

(Die endgültige Grösse kann variieren)</small>"""
    format_target_info_nothing = """Du must mindestens einen von beiden \
Streams (Audio oder Video) aktivieren."""
    format_target_no_file = "Du hast noch keine valide Datei gewählt."

### OUTPUT/PROCEED

    proceed_folder_label = """Verzeichnis"""
    proceed_suffix_label = """Container"""
    proceed_name_label = """Name"""
    
    frame_output = """Ausgabe"""
    frame_proceed = """Ausführen"""
    
    out_file_menu_path = "Pfad wie Quelle"
    out_file_menu_name = "Name wie Quelle"
    
### SETTINGS
    
    settings_language_label = "Sprache wählen"
    settings_reset_label = "Das Programm auf Ausgangswerte zurücksetzen"
    settings_reset_button = "Zurücksetzen"
    settings_video_filter_label = "Welche Option für Beschneiden/Erweitern"
    settings_bitrate_mode_label = "Welche Option für Bitrate"
    settings_cpu_label = "CPU-Last"
    settings_progress_actions = "Aktion nach Fertigstellung"
    settings_cleanup_2_pass_label = "Log nach 2-Pass löschen"
    settings_ffmpeg_label = "FFmpeg"
    settings_tragtor_label = "traGtor"
    settings_version_label = "<b>Infos über FFmpeg und traGtor</b>"
    settings_stream_label = "Welcher Stream Separator\n(.) für aconv, (:) für ffmpeg"
    settings_newstream_label = "Benutze \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Leerraum", "Beschneiden", "Verzerren" ]
    output_file_suffix_auto = "Wie unten angegeben"
    cpu_usage_modes = ["Wenig", "Medium", "Aggressiv"]
    video_filters = ["Pad, Crop & Size (alt)",
                     "Video Filter (x:y:w:h)",
                     "Video Filter (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (alt)",
                     "-b:v / -b:a (neu)"]
    progress_actions = ["Nichts", "Datei abspielen", "Fortschrittsfenster schließen",
                        "traGtor schließen", "Rechner ausschalten", "Rechner in Ruhezustand",
                        "Rechner in Schlafzustand"]
    stream_separators = [".", ":"]
                     
### SYSTEM

    datestring = "%d.%m.%Y %H:%M:%S"
    hour = "Stunde"
    hours = "Stunden"
    minute = "Minute"
    minutes = "Minuten"
    second = "Sekunde"
    seconds = "Sekunden"
    frames = "Bilder"
    _and = "und"
    
    changed = "geändert!"
    
    title_in_file_media_files = "Lesbare Mediendateien"
    title_in_file_all_files = "Alle Dateien"
    title_out_file_media_files = "Schreibbare Mediendateien"
    title_out_file_all_files = "Alle Dateien"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Bestätigung"
    label_confirmation = """Sind die Einstellungen
so richtig? Du kannst
die Befehlszeile auch
bearbeiten, die an ffmpeg
geschickt wird.
"""
    label_confirm_commandline = "Befehlszeile"
    label_confirm_in_file = "<b>Quelle:</b> %s"
    label_confirm_in_files = "<b>Quellen:</b> %s"
    label_confirm_out_file = "<b>Ziel:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Leerraum:</b> füge %i Pixel der Breite hinzu"
    label_confirm_pad_v = "<b>Leerraum:</b> füge %i Pixel der Höhe hinzu"
    label_confirm_crop_h = "<b>Beschnitt:</b> beschneide Breite um %i Pixel"
    label_confirm_crop_v = "<b>Beschnitt:</b> beschneide Höhe um %i Pixel"
    label_confirm_distort_h = "<b>Skalierung:</b> dehne Breite auf %i\%"
    label_confirm_distort_v = "<b>Skalierung:</b> dehne Höhe auf %i\%"
    label_confirm_format = "<b>Format:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "deaktiviert"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Dauer:</b> %s"
    label_confirm_offset = "<b>Start:</b> %s"
    label_confirm_size = "<b>Größe:</b> %s"

### PROCESS
    
    title_progress_window = "Wird bearbeitet..."
    title_progress_window_finished = "Abgeschlossen"
    title_progress_window_error = "Fehler!"
    title_progress_window_pass = "(Pass %i)"
    label_progress = "Die Datei wird bearbeitet..."
    text_progress = "Status der Datei\n%s"
    
    label_progress_size = "<b>Größe</b>"
    label_progress_bitrate = "<b>Bitrate</b>"
    label_progress_time = "<b>Zeit</b>"
    label_progress_frame = "<b>Frame</b>"
    label_progress_quantizer = "<b>Quantizer</b>"
    label_progress_video = "<b>Video</b>"
    label_progress_audio = "<b>Audio</b>"
    label_progress_headers = "<b>Header</b>"
    label_progress_overhead = "<b>Überhang</b>"
    
    label_progress_error = "<b>Fehler!</b>"
    label_progress_error_explain = "Es ist scheinbar ein Fehler aufgetreten. \
In dem Textfeld findest Du die Ausgabe von FFmpeg."
    label_progress_actions = "Anschließend"
    
### HELP-WINDOW

    title_help_window = "Hilfe"
    
### UOE window
    
    label_pass_1 = "Pass 1"
    label_pass_2 = "Pass 2"
    label_single = "Optionen"
    label_UOE = """Bearbeite hier Deine
Optionen. Benutze keine
Zeilenumbrüche. Wenn Du
2-Pass aktiviert hast,
werden beide Felder mit
einer Pipe | verbunden
eingefügt."""
