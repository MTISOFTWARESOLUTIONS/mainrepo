#!/usr/bin/env python
# coding: UTF-8

class tragtorLang:
    
    language = "fr"

### ERRORS

    error_in_file_single = """Une erreur est survenue à l'ouverture!\n\nSouhaitez-vous obtenir plus d'information?"""

    error_in_file_multi = """À l'ouverture, %i erreurs sont survenue(s)!\n\nSouhaitez-vous obtenir plus d'information?"""

    error_in_file_not_accessible = """### ERROR [not_accessible]:

Le fichier '%s' n'est pas lisible.""" 

    error_in_file_not_accessible_explain = """Merci de choisir le fichier média correct et de vérifier que vous disposez des droits appropriés sur celui-ci.

Il se peut que cette erreur apparaisse suite à un fichier de 0 octets."""

    error_in_file_not_readable = """### ERROR [not_readable]:

Le fichier '%s' ne peut pas être traité. Vous ne pouvez pas traiter un fichier non lisible."""
    
    error_in_file_not_readable_explain = """### INFO [not_readable]:

    Etes-vous sûr que vous avez installé les codecs requis ?    

    Selon comment vous avez compilé FFmpeg, il se peut aussi qu'il y ait 
    des problèmes d'options du compilateur
    
    Dans la plupart des versions d'Ubuntu par exemple, il manque le support de mp3 dans FFmpeg.
    Pour résoudre ce problème, vous devez A) compiler les sources de FFmpeg vous-même
    ou B) installer les paquets à partir du dépot medibuntu
    à l'aide de la fonction 'forcer la version' de Synaptics.
    Plus d'informations sont disponibles:

    https://help.ubuntu.com/community/Medibuntu
    http://ffmpeg.mplayerhq.hu/
    http://wiki.ubuntuusers.de/FFmpeg (German)
    http://www.google.com/search?q=ffmpeg"""
    
    ffmpeg_options = """### FFMPEG-Configuration
    
# Les actuelles options de compilations de FFmpeg sont les suivantes:
    %s

# Formats de fichier lisibles:
    %s
    
# Formats de fichier inscriptibles:
    %s

# Codecs audio lisibles:
    %s
    
# Codecs audio inscriptibles:
    %s

# Codecs vidéo lisibles:
    %s

# Codecs vidéo inscriptibles:
    %s
"""
    error_message_title = "Error!"
    error_message_file_not_readable = "Le fichier source que vous avez spécifié n'est pas lisible!"
    error_message_file_not_in_media = "Le fichier source que vous avez spécifié n'est pas importable!"
    error_message_file_not_writable = "Le fichier de destination que vous avez spécifié n'est pas inscriptible!"
    error_message_file_not_out_media = "Le fichier de destination que vous avez spécifié n'est pas exportable!"
    error_message_no_opener = "Le fichier ne peut pas être ouvert car ni gnome-open ni kde-open ne semblent être installés."
    error_message_no_audio = "Aucun flux audio présent"
    error_message_no_video = "Aucun flux vidéo présent"
    
    error_message_delete_failed = """Le fichier ne peut pas être supprimé.
Avez-vous les bonnes permissions?"""
    error_message_no_manual = "Aucune entrée de manuel n'est disponible pour FFmpeg."
    
    error_button_not_in_media = "Aucune source traitable"
    error_button_not_writable = "La destination ne peut pas être créée"
    error_button_not_out_media = "La destination n'est pas traitable"
    error_button_in_as_out = "La destination et la source sont le même fichier"
    error_button_duration = "Les paramètres de temps sont incorrects"
    error_button_size = "Vous voulez créer un fichier vidéo de taille 0 ?"
    error_button_bitrate = "La valeur du bitrate est invalide"
    error_button_frame_rate = "La valeur du frame rate est invalide"
    error_button_sample_rate = "La valeur de la sample rate est invalide"
    error_button_channels = "La valeur des canaux audio est invalide"
    error_button_no_audio = "Vous voulez créer un fichier audio sans audio?"
    error_button_no_content = "Vous voulez créer un fichier sans contenu?"
    error_button_no_audio_bitrate = "Vous voulez créer un fichier audio de 0 kb/s?"
    error_button_no_video_bitrate = "Vous voulez créer un fichier vidéo de 0 kb/s?"
    
    error_cant_proceed = "Vous ne pouvez pas poursuivre avec ces paramètres."
        
### BUTTONS

    proceed_button_active = "Montre moi la lumière!"
    proceed_button_overwrite = "Voulez vous re-traiter?\nLe fichier va être réécrit"
    proceed_button_inactive = "Traitement impossible\n%s"
    
### IN FILE TEXT AREA

    in_file_text_area_pre = """### Information concernant le fichier source:
"""
    in_file_text_area_post = ""
    in_file_format_info = """
    Fichier: %s
    Taille: %Octets
    Conteneur: %s
    Bitrate: %s k/bs
    Durée: %s
"""
    in_file_stream_main_info = """
    Stream-ID: %s
    Format: %s
    Codec: %s
"""    
    in_file_stream_audio_info = """    Sample_Rate: %s hz
    Canaux: %s
    Bitrate audio: %s kb/s
"""
    in_file_stream_video_info = """    Méthode: %s
    Taille: %s
    FPS: %s fps
"""

### IN FILE

    in_file_audio_label = "Flux Audio"
    in_file_video_label = "Flux Vidéo"
    in_file_open_label = "Fichiers Sélectionnés"
    in_file_add_label = "Plusieurs"
    in_file_select_label = "Seul"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "Fichier"
    in_file_open_size = "Taille"
    in_file_open_container = "Format"
    in_file_open_duration = "Durée"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "Sample Rate"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Canaux"
    in_file_audio_language = "Langage"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_codec = "Codec"
    in_file_video_size = "Taille"
    in_file_video_fps = "FPS"
    in_file_video_method = "Methode"
    in_file_video_language = "Langage"
    
    in_file_menu_path = "Chemin de la sortie"
    in_file_menu_name = "Nom de la sortie"
    in_file_menu_meta = "Adopter ID3"
    
### META COMMENT
    
    meta_comment_text = """Encoder FFmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Confirmation"
    question_overwrite_preset = "Voulez-vous vraiment réécrire %s?"
    question_delete_preset = "Voulez-vous vraiment supprimer %s?"
    question_delete_in_file = "Voulez-vous vraiment supprimer #%i du disque?"

### TEXT LABELS

    # page-labels
    in_file_label = """Merci de sélectionner en premier
le(s) fichier(s) que 
vous voudriez converir

Les flux audio et vidéo 
apparaitront en dessous
de la sélection
    
Utiliser le bouton "seul" 
pour travailler avec un 
seul fichier

Utiliser le bouton "plusieurs"
pour travailler avec 
plusieurs fichiers

Clic droit sur un fichier
afin d'avoir le menu d'options"""

    suffix_label = "Conteneur:"

    meta_label = """Editer les métadonnées 
du fichier média final

Les informations stockées
n'affectent en rien les données 
relatives au fichier (comme son nom)

Certains formats peuvent
ne pas supporter ceci!"""

    proceed_label = """Cliquez sur le bouton suivant afin de procéder.

Le grand bouton vous informera comment se passent les choses.

S'il est activé, il apparaitra une demande de confirmation avant de procéder.

La sortie de FFmpeg s'affichera dans la zone droite\njuste après qu'il ait fini."""

    format_video_label = "Paramètres Vidéo"
    format_audio_label = "Paramètres Audio"
    format_render_label = "Paramètres du Rendu"
    format_results_label = "Résultats"
    settings_label = """Paramètres basiques du GUI"""
    
### NOTEBOOKS

    in_file_notebook = "Sources"
    format_notebook = "Format"
    meta_notebook = "Meta"
    proceed_notebook = "Procéder"
    settings_notebook = "Paramètres"

### TITLES

    in_file_title = "Choisir une source"
    format_title = "Fixer un format"
    meta_title = "Changer les Metadonnées"
    proceed_title = "Procéder"
    settings_title = "Paramètres"

### INPUT_VALUES

    meta_title_label = "Titre:"
    meta_author_label = "Auteur:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Commentaire:"
    meta_toggle_label = "Utiliser les Metadonnées"
    
    format_width_label = "Largeur:"
    format_height_label = "Hauteur:"
    format_ratio_label = "Ratio:"
    format_fixed_ratio_label = "Ratio fixé:"
    format_frame_rate_label = "Frame Rate / s:"
    format_deinterlace_label = "Désentrelacement:"
    
    format_audio_sample_rate_label = "Sample Rate:"
    format_audio_bitrate_label = "Bitrate (kb/s):"
    format_audio_codec_label = "Forcer le codec:"
    format_audio_channels_label = "Canaux audio:"
    format_2_pass_label = "2-Passes:"
    format_2_pass_no_audio_label = "Sauter l'audio:"
    format_codec_label = "Forcer le codec:"
    format_bitrate_label = "Bitrate (kb/s):"
    format_offset_label = "Commencer à:"
    format_duration_label = "Durée:"
    format_scaling_label = "Scaling:"
    format_pad_color_label = "Couleur de remplissage:"
    format_volume_label = "Volume:"
    format_user_defined_label = "Options additionnelles:"
    format_manual_button = "Manuel FFmpeg"
    
    format_tooltip_changed = "Reset to %s"
    
### PRESETS
    
    presets_label = "Définis d'avance"
    presets_container = """Fixer le conteneur
du fichier de sortie"""

### FORMAT-INFO
    
    format_target_info_av = """<b>%s - %sOctets</b>"""

    format_target_info_video = """Contenu vidéo sans flux audio: \
<b>%s</b> - <b>%sOctets</b>."""

    format_target_info_audio = """<b>%s - %sOctets</b>"""

    format_target_info = """%s<small>

(La taille résultante peut différer)</small>"""
    format_target_info_nothing = """Vous devez activer au moins un \
des flux (audio ou video)."""
    format_target_no_file = "<b>Aucun fichier valide sélectionné!</b>"

### OUTPUT/PROCEED

    proceed_folder_label = """Dossier"""
    proceed_suffix_label = """Conteneur"""
    proceed_name_label = """Nom"""
    
    frame_output = """Sortie"""
    frame_proceed = """Procéder"""
    
    out_file_menu_path = "Même chemin"
    out_file_menu_name = "Même nom"
    
### SETTINGS
    
    settings_language_label ="Choisissez votre langue"
    settings_reset_label = "Remise à zéro aux valeurs par défaut et recommencer de nouveau"
    settings_reset_button = "Reset"
    settings_video_filter_label = "Sélectionnez les options de 'Pad And Crop'"
    settings_bitrate_mode_label = "Sélectionnez les options de Bitrate"
    settings_cpu_label = "Usage du CPU"
    settings_progress_actions = "Action après traitement"
    settings_cleanup_2_pass_label = "Supprimer les logs après 2-passes"
    settings_ffmpeg_label = "FFmpeg:"
    settings_tragtor_label = "traGtor:"
    settings_version_label = "Informations à propos de FFmpeg et traGtor"
    settings_stream_label = "Sélectionnez le séparateur de flux\n(.) si utilisation de avconv, (:) si utilisation de ffmpeg"
    settings_newstream_label = "Use \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Pad", "Crop", "Distort" ]
    output_file_suffix_auto = "comme il est indiqué après"
    cpu_usage_modes = ["Soft", "Medium", "Aggressive"]
    video_filters = ["Pad, Crop & Size (Ancien)",
                     "Filtre Vidéo (x:y:w:h)",
                     "Filtre Vidéo (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (ancien)",
                     "-b:v / -b:a (nouveau)"]
    progress_actions = ["Rien", "Jouer le fichier", "Fermer la fenêtre de progression",
                     "Fermer traGtor", "Éteindre", "Hiberner",
                     "Suspendre"]
    stream_separators = [".", ":"]
                     
### SYSTEM
    
    date_string = "%Y-%m-%d %I:%M:%S %p"
    hour = "heure"
    hours = "heures"
    minute = "minute"
    minutes = "minutes"
    second = "seconde"
    seconds = "secondes"
    frames = "frames"
    _and = "et"
    
    changed = "changé!"
    
    title_in_file_media_files = "Fichiers média lisibles"
    title_in_file_all_files = "Tous les formats de fichier"
    title_out_file_media_files = "Fichiers média inscriptibles"
    title_out_file_all_files = "Tous les formats de fichier"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Confirmation"
    label_confirmation = """Confirmez vos paramètres de droite.

Vous pouvez faire quelques changements à l'aide de la ligne de commande"""
    label_confirm_commandline = "Ligne de commande"
    label_confirm_in_file = "<b>Source:</b> %s"
    label_confirm_in_files = "<b>Sources:</b> %s"
    label_confirm_out_file = "<b>Destination:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Pad:</b> ajouter %i pixels à la largeur"
    label_confirm_pad_v = "<b>Pad:</b> ajouter %i pixels à la hauteur"
    label_confirm_crop_h = "<b>Crop:</b> extraire %i pixels à la largeur"
    label_confirm_crop_v = "<b>Crop:</b> extraire %i pixels à la hauteur"
    label_confirm_distort_h = "<b>Scaling:</b> étirer la largeur à %i\%"
    label_confirm_distort_v = "<b>Scaling:</b> étirer la hauteur à %i\%"
    label_confirm_format = "<b>Format:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "désactivé"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Durée:</b> %s"
    label_confirm_offset = "<b>Commencement:</b> %s"
    label_confirm_size = "<b>Taille:</b> %s"

### PROCESS

    title_progress_window = "En progression..."
    title_progress_window_finished = "Fini."
    title_progress_window_error = "Erreur!"
    title_progress_window_pass = "(passe %i)"
    label_progress = "Traitement..."
    text_progress = "Statut du fichier\n%s"

    label_progress_size = "<b>Taille:</b>"
    label_progress_bitrate = "<b>Bitrate:</b>"
    label_progress_time = "<b>Temps:</b>"
    label_progress_frame = "<b>Frame:</b>"
    label_progress_quantizer = "<b>Quantificateur:</b>"
    label_progress_video = "<b>Video:</b>"
    label_progress_audio = "<b>Audio:</b>"
    label_progress_headers = "<b>Headers:</b>"
    label_progress_overhead = "<b>Overhead:</b>"
    
    label_progress_error = "<b>Erreur!</b>"
    label_progress_error_explain = "Il semblerait qu'il y ait eu une erreur. \
Merci de vous référer à la zone de texte de la sortie de FFmpeg."
    label_progress_actions = "À la fin"

### HELP-WINDOW

    title_help_window = "Aide"
    
### UOE window
    
    label_pass_1 = "Passe 1"
    label_pass_2 = "Passe 2"
    label_single = "Options"
    label_UOE = """Éditez vos options d'usage
ici. N'utilisez pas de sauts de ligne.
Si vous avez 2 passes activées
toutes les deux les champs seront concaténés
avec le symbole de pipe | dans le champ d'option."""
