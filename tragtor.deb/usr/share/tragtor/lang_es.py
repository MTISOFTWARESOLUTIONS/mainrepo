#!/usr/bin/env python
# coding: UTF-8
class tragtorLang:
    
    language = "es"

### ERRORS

    error_in_file_single = """Se produjo un error en la apertura!\nDesea ver un poco más de información?"""
    
    error_in_file_multi = """Al abrir %i se produjo un error!\nDesea ver un poco más de información?"""
    
    error_in_file_not_accessible = """### ERROR [not_accessible]:
    El archivo '%s' no es legible."""
    
    error_in_file_not_accessible_explain = """Por favor, asegurese que usted ha elegido
    un archivo normal y tiene los derechos apropiados para acceder a él.
    
    A veces, este error puede ocurrir debido a un archivo de cero bytes.
"""
    error_in_file_not_readable = """### ERROR [not_readable]:
      
    El archivo '%s' no es procesable. No se puede proceder con un archivo ilegible."""
    
    error_in_file_not_readable_explain = """### INFO [not_readable]:
    
    Está usted seguro que tiene todos los codecs adecuados instalados?
    Dependiendo de la forma en que ha compilado ffmpeg  también puede
    ser un problema con la falta de opciones del compilador.
    
    La mayoría de versiones de Ubuntu, por ejemplo, carecen de soporte para mp3 en ffmpeg.
    Para hacer frente a esto usted tiene que a) compilar el código fuente del ffmpeg
    o b) para Ubuntu - instalar los paquetes de los repositorios medibuntu
    a través de la función 'fuerza version' de synaptic.
    Más información está disponible en:
    
    http://ffmpeg.mplayerhq.hu/
    http://www.thedesignexperience.org/weblog/one-entry?entry_id=113488
    http://wiki.ubuntuusers.de/FFmpeg (german)
    
    y seguramente en http://www.google.com/search?q=ffmpeg"""
    
    ffmpeg_options = """### FFMPEG-Configuración
    
# Sus actuales opciones de compilación de ffmpeg son las siguientes:
    %s

# Formatos de archivo legible:
    %s
    
# formatos de archivo escribible:
    %s

# Legible de audio-codecs:
    %s
    
# Grabables de audio-codecs:
    %s

# Legible de video-codecs:
    %s

# Grabables de video-codecs:
    %s
"""
    error_message_title = "Error!"
    error_message_file_not_readable = "El archivo origen que has especificado no es legible!"
    error_message_file_not_in_media = "El archivo origen que has especificado no contiene Multimedia importable!"
    error_message_file_not_writable = "El targetfile que has especificado no se puede escribir!"
    error_message_file_not_out_media = "El targetfile que has especificado no contiene Multimedia exportable!"
    error_message_no_opener = "El archivo no se puede abrir porque ni gnome-open\nni kde-open parecen estar instalados."
    error_message_no_audio = "No hay flujos de audio"
    error_message_no_video = "No hay flujos de video"
    
    error_message_delete_failed = """El archivo no pudo ser eliminado.
Tiene usted los permisos requeridos?"""
    error_message_no_manual = "No hay entrada manual para FFmpeg disponible."
    
    error_button_not_in_media = "Ninguna fuente procesable"
    error_button_not_writable = "El objetivo no se puede escribir"
    error_button_not_out_media = "El objetivo no contiene multimedia procesable"
    error_button_in_as_out = "Origen y destino son el mismo archivo"
    error_button_duration = "El time-settings es incorrecto"
    error_button_size = "Quieres crear un video de tamaño-0"
    error_button_bitrate = "El valor de la tasa de bits no es válido"
    error_button_frame_rate = "El valor de la tasa de fotogramas no es válido"
    error_button_sample_rate = "El valor de la frecuencia de muestreo no es válido"
    error_button_channels = "El valor de canales de audio no es válido"
    error_button_no_audio = "Desea crear un archivo de audio sin audio"
    error_button_no_content = "Desea crear un archivo sin ningún tipo de contenido"
    error_button_no_audio_bitrate = "Quieres crear un archivo de audio de 0 kb/s"
    error_button_no_video_bitrate = "Quieres crear un archivo de video de 0 kb/s"
    
    error_cant_proceed = "No se puede seguir con estos ajustes."
        
### BUTTONS

    proceed_button_active = "Muéstrame la luz!"
    proceed_button_overwrite = "Aquí vamos ... pero\nel archivo se sobrescribirá"
    proceed_button_inactive = "Procedimiento imposible:\n%s"
    
### INFILE TEXTAREA

    in_file_textarea_pre = """### Información acerca del archivo de origen:
"""
    in_file_textarea_post = ""
    in_file_format_info = """
    Archivo:%s
    Tamaño:%sBytes
    Contenedor:%s
    Tasa de bits:%s k/bs
    Duración:%s
"""
    in_file_stream_main_info = """
    Stream-ID:%s
    Formato:%s
    Codec:%s
"""    
    in_file_stream_audio_info = """    tasa de muestreo:%s hz
    Canales:%s
    Audio-Tasa de bits:%s kb/s
"""
    in_file_stream_video_info = """    Metodo:%s
    Tamaño:%s
    FPS:%s fps
"""

### INFILE

    in_file_audio_label = "Flujo de audio"
    in_file_video_label = "Flujo de Video"
    in_file_open_label = "archivos seleccionados"
    in_file_add_label = "Multiple"
    in_file_select_label = "Simple"
    
    in_file_open_remove = ""
    in_file_open_id = ""
    in_file_open_file = "Archivo"
    in_file_open_size = "Tamaño"
    in_file_open_container = "Formato"
    in_file_open_duration = "Duración"
    
    in_file_audio_id = "⇨"
    in_file_audio_select = "♻"
    in_file_audio_file = ""
    in_file_audio_codec = "Codec"
    in_file_audio_sample_rate = "tasa de muestreo"
    in_file_audio_bitrate = "kb/s"
    in_file_audio_channels = "Canales"
    in_file_audio_language = "Idioma"
    
    in_file_video_preview = "▣"
    in_file_video_id = "⇨"
    in_file_video_select = "♻"
    in_file_video_file = ""
    in_file_video_codec = "Codec"
    in_file_video_size = "Tamaño"
    in_file_video_fps = "FPS"
    in_file_video_method = "Metodo"
    in_file_video_language = "Idioma"
    
    in_file_menu_path = "Ruta de salida"
    in_file_menu_name = "Nombre de salida"
    in_file_menu_meta = "Adoptar ID3"
    
### META COMMENT
    
    meta_comment_text = """Encoder ffmpeg & traGtor"""
    
### QUESTIONS/CONFIRMATIONS
    
    question_title = "Confirmación"
    question_overwrite_preset = "De verdad quieres sobreescribir %s?"
    question_delete_preset = "Realmente quiere eliminar %s?"
    question_delete_in_file = "Realmente desea eliminar el archivo #%i del disco?\n(No se podra deshacer!)"

### TEXTLABELS

    # page-labels
    in_file_label = """Para comenzar por favor seleccione \
un archivo a convertir. Si éste es un archivo multimedia \
procesable, el audio incluido \
y secuencias de vídeo aparecerán a la derecha de la selección. \
Si el botón "Multiple" está activado, los archivos seleccionados se agregan \
a la lista, "Simple" reemplaza todo con un solo archivo.\
Obtenga un menú con opciones, haciendo clic derecho en un archivo."""
    suffix_label = "Contenedor:"
    meta_label = """Editar los metadatos del multimedia final. \
Estos datos serán almacenados en los multimedia y no afectan \
los valores relacionados con archivos, como el nombre del archivo.\n(Algunos formatos tal vez no sean compatibles con esto!)"""
    proceed_label = """Continuar con su configuración. \
El botón grande le informará como van las cosas. \
Si está activo, aparecerá una confirmación antes de proceder.
La salida de FFmpeg se mostrará en el área derecha\njusto después de que haya terminado."""
    format_video_label = "Ajustes de video"
    format_audio_label = "Ajustes de audio"
    format_render_label = "Ajustes de renderizado"
    format_results_label = "Resultados"
    settings_label = """Aquí usted puede hacer algunos \
ajustes básicos de esta GUI."""
    
### NOTEBOOKS

    in_file_notebook = "Fuentes"
    format_notebook = "Formato"
    meta_notebook = "Metadatos"
    proceed_notebook = "Proceder"
    settings_notebook = "Configuración"

### TITLES

    in_file_title = "Elegir la fuente"
    format_title = "Determinar formato"
    meta_title = "Cambiar metadatos"
    proceed_title = "Proceder"
    settings_title = "Configuración"

### INPUT_VALUES

    meta_title_label = "Título:"
    meta_author_label = "Autor:"
    meta_copyleft_label = "Copyright:"
    meta_comment_label = "Comentario:"
    meta_toggle_label = "Usar metadatos"
    
    format_width_label = "Ancho:"
    format_height_label = "Altura:"
    format_ratio_label = "Tasa:"
    format_fixed_ratio_label = "Tasa fija:"
    format_frame_rate_label = "Frames por segundo:"
    format_deinterlace_label = "Desentrelazado:"
    
    format_audio_sample_rate_label = "Tasa de muestreo:"
    format_audio_bitrate_label = "Tasa de bits (kb/s):"
    format_audio_codec_label = "Forzar codec:"
    format_audio_channels_label = "Canales de Audio:"
    format_2_pass_label = "2-pasadas:"
    format_2_pass_no_audio_label = "Saltar audio:"
    format_codec_label = "Forzar codec:"
    format_bitrate_label = "Tasa de bits (kb/s):"
    format_offset_label = "Inicio en:"
    format_duration_label = "Duración:"
    format_scaling_label = "Escala:"
    format_pad_color_label = "Relleno de color:"
    format_volume_label = "Volumen:"
    format_user_defined_label = "Opciones adicionales:"
    format_manual_button = "Manual FFmpeg"
    
    format_tooltip_changed = "Reset to %s"
    
### PRESETS
    
    presets_label = "Preestablecidos"
    presets_container = """Establecer contenedor
del archivo de salida"""

### FORMAT-INFO
    
    format_target_info_av = """Un archivo incluyendo sonido y vídeo \
será <b>%s</b> de largo y aproximadamente <b>%sBytes</b> de espacio."""
    format_target_info_video = """contenido de video puro, sin flujo de audio \
y la duración de <b>%s</b> tomará aproximadamente <b>%sBytes</b>."""
    format_target_info_audio = """Un archivo de audio puro de  \
<b>%s</b> tomará <b>%s</b> con estos ajustes."""
    format_target_info = """%s<small>

(El tamaño resultante puede ser diferente)</small>"""
    format_target_info_nothing = """Tienes que activar al menos uno \
de los flujos (audio o video)."""
    format_target_no_file = "No ha elegido ningún archivo válido."
    
### OUTPUT/PROCEED

    proceed_folder_label = """Ruta"""
    proceed_suffix_label = """Container"""
    proceed_name_label = """Nombre"""
    
    frame_output = """Objetivo"""
    frame_proceed = """Proceder"""
    
    out_file_menu_path = "la misma ruta"
    out_file_menu_name = "el mismo nombre"
    
### SETTINGS
    
    settings_language_label ="Elija su idioma"
    settings_reset_label = "Restablecer todos los valores\npor defecto y empezar de nuevo"
    settings_reset_button = "Restablecer"
    settings_video_filter_label = "Seleccione su opción de Pad y Crop"
    settings_bitrate_mode_label = "Seleccione su opción de Bitrate"
    settings_cpu_label = "Uso de la CPU"
    settings_progress_actions = "Accion post-elaboracion"
    settings_cleanup_2_pass_label = "Limpiar Log despues de 2-Pasadas"
    settings_ffmpeg_label = "FFmpeg"
    settings_tragtor_label = "traGtor"
    settings_version_label = "Información sobre FFmpeg y traGtor"
    settings_stream_label = "Selecciona separador de stream\n(.) si usas avconv, (:) si usas ffmpeg"
    settings_newstream_label = "Use \"new[audio|video]\" Option"
    
### LISTS

    format_scaling_methods_list = [ "Pad", "Crop", "Distort" ]
    output_file_suffix_auto = "como se indica a continuación"
    cpu_usage_modes = ["Soft", "Medium", "Aggressive"]
    video_filters = ["Pad, Crop & Size (clasico)",
                     "Video Filter (x:y:w:h)",
                     "Video Filter (w:h:x:y)"]
    bitrate_modes = ["-b / -ab (clasico)",
                     "-b:v / -b:a (nuevo)"]
    progress_actions = ["No hacer nada", "Reproducir archivo", "Cerrar ventana elaboracion",
                     "Cerrar traGtor", "Apagar PC", "Hibernar PC",
                     "Suspender PC"]
    stream_separators = [".", ":"]
                     
### SYSTEM
    
    datestring = "%Y-%m-%d %I:%M:%S %p"
    hour = "hora"
    hours = "horas"
    minute = "minuto"
    minutes = "minutos"
    second = "segundo"
    seconds = "segundos"
    frames = "fotogramas"
    _and = "y"
    
    changed = "cambiado!"
    
    title_in_file_media_files = "Archivos multimedia legibles"
    title_in_file_all_files = "Todos los formatos de archivo"
    title_out_file_media_files = "Archivos multimedia grabables"
    title_out_file_all_files = "Todos los formatos de archivo"

### CONFIRMATION-WINDOW

    title_confirmation_window = "Confirmación"
    label_confirmation = """Por favor verifique los ajustes \
de la derecha. Usted puede hacer algunos cambios en la \
línea de comandos para ffmpeg."""
    label_confirm_commandline = "Línea de comandos"
    label_confirm_in_file = "<b>Fuente:</b> %s"
    label_confirm_in_files = "<b>Fuentes:</b> %s"
    label_confirm_out_file = "<b>Objetivo:</b> %s"
    label_confirm_in_size = "(%sB)"
    label_confirm_out_size = "(~ %sB)"
    label_confirm_pad_h = "<b>Pad:</b> agregando %i pixel de ancho"
    label_confirm_pad_v = "<b>Pad:</b> agregando %i pixel de alto"
    label_confirm_crop_h = "<b>Crop:</b> extrayendo %i pixel de ancho"
    label_confirm_crop_v = "<b>Crop:</b> extrayendo %i pixel de alto"
    label_confirm_distort_h = "<b>Escalando:</b> estirando ancho de %i\%"
    label_confirm_distort_v = "<b>Escalando:</b> estirando alto de %i\%"
    label_confirm_format = "<b>Formato:</b> %s"
    label_confirm_audio = "<b>Audio:</b> %s"
    label_confirm_audio_disabled = "desactivado"
    label_confirm_video = "<b>Video:</b> %s"
    label_confirm_duration = "<b>Duración:</b> %s"
    label_confirm_offset = "<b>Inicio:</b> %s"
    label_confirm_size = "<b>Tamaño:</b> %s"

### PROCESS

    title_progress_window = "Procesando..."
    title_progress_window_finished = "Finalizado."
    title_progress_window_error = "Error!"
    title_progress_window_pass = "(pasadas %i)"
    label_progress = "El archivo está en proceso..."
    text_progress = "Estado del archivo\n%s"

    label_progress_size = "<b>Tamaño</b>"
    label_progress_bitrate = "<b>Tasa de bits</b>"
    label_progress_time = "<b>Tiempo</b>"
    label_progress_frame = "<b>Fotograma</b>"
    label_progress_quantizer = "<b>Cuantizador</b>"
    label_progress_video = "<b>Video</b>"
    label_progress_audio = "<b>Audio</b>"
    label_progress_headers = "<b>Cabeceras</b>"
    label_progress_overhead = "<b>Overhead</b>"
    
    label_progress_error = "<b>Error!</b>"
    label_progress_error_explain = "Parece que hubo un error. \
Por favor, consulte el área de texto de salida de ffmpeg."
    label_progress_actions = "Al finalizar"


### HELP-WINDOW

    title_help_window = "Ayuda"
    
### UOE window
    
    label_pass_1 = "1 Pasada"
    label_pass_2 = "2 Pasadas"
    label_single = "Opciones"
    label_UOE = """Edite sus opciones de usuario
aqui. No use saltos de 
linea. Si usted tiene
2 pasadas habilitadas ambos
campos serán concatenados
con una barra vertical | en
el campo de opciones."""
