#!/bin/bash
# Ultimate Player display script by TheeMahn <theemahn@ultimateedition.info>
#
# requirements: ultimate-player (!), qdbus, radiotray, pithos
#

#function (UP)
QDBUS=$(which qdbus)
if ! [[ "$QDBUS" ]]; then
    # Exit graciously, no qdbus
    exit 0;
fi

function Clementine() {
    ART=$(qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2  org.mpris.MediaPlayer2.Player.Metadata | grep artUrl:  | cut -d " " -f2 | sed "s/file:\/\///g");
    if [[ -f "$ART" ]]; then
        #echo "cOPYING $ART to ~/.config/Ultimate-Player/Current.art"
        cp "$ART" ~/.config/Ultimate-Player/Current.art
    fi
    #echo "1: $1 2: $2"
    case "$2" in
    artist)
       qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2  org.mpris.MediaPlayer2.Player.Metadata | grep xesam:artist | cut -d: -f3;;
    title)
       qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2  org.mpris.MediaPlayer2.Player.Metadata | grep xesam:title | cut -d: -f3;;
    album)
       qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2  org.mpris.MediaPlayer2.Player.Metadata | grep -m1 xesam:album | cut -d: -f3;;
    progress)
    
    curr=$(qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Position)
    tot=$(qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2  org.mpris.MediaPlayer2.Player.Metadata | grep mpris:length | cut -d: -f3)
    if [[ "$tot" ]]; then
        (("$curr" \* 100 / "$tot"))
    fi
    ;;
currenttime)
    tmp=$(qdbus org.mpris.MediaPlayer2.clementine /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Position)
    min=$(("$tmp" / 60000))
    sec_full=`expr $tmp % 60000`
    c=`expr $sec_full \< 10000`
    if (($c)); then
sec=`expr substr $sec_full 1 1`
        echo $min:0$sec
    else
sec=`expr substr $sec_full 1 2`
        echo $min:$sec
    fi
    ;;
totaltime)
    tmp=`qdbus org.mpris.ultimateplayer /Player GetMetadata | grep mtime: | cut -b 8-`
    min=`expr $tmp / 60000`
    sec_full=`expr $tmp % 60000`
    c=`expr $sec_full \< 10000`
    if (($c)); then
sec=`expr substr $sec_full 1 1`
        echo $min:0$sec
    else
sec=`expr substr $sec_full 1 2`
        echo $min:$sec
    fi
    ;;
timeleft)
    curr=`qdbus org.mpris.ultimateplayer /Player PositionGet`
    tot=`qdbus org.mpris.ultimateplayer /Player GetMetadata | grep mtime: | cut -b 8-`
    left=`expr $tot - $curr`
    min=`expr $left / 60000`
    sec_full=`expr $left % 60000`
    c=`expr $sec_full \< 10000`
    if (($c)); then
sec=`expr substr $sec_full 1 1`
        echo $min:0$sec
    else
sec=`expr substr $sec_full 1 2`
        echo $min:$sec
    fi
    ;;
    esac
}


function Pithos () {
    if ! [[ "$2" ]]; then
        ART=$(qdbus org.mpris.MediaPlayer2.pithos /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Metadata | grep mpris:artUrl | cut -d " " -f2)
        if [[ "$ART" ]]; then
            if [[ -f ~/.config/Ultimate-Player/Current.art ]];then
                rm -f ~/.config/Ultimate-Player/Current.art
                wget "$ART" -c -O ~/.config/Ultimate-Player/Current.art
                #qdbus org.mpris.MediaPlayer2.pithos /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.PlaybackStatus
            fi
        fi
    fi
    case "$2" in
    artist)
        qdbus org.mpris.MediaPlayer2.pithos /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Metadata | grep xesam:artist | cut -d: -f3;;
    title)
        qdbus org.mpris.MediaPlayer2.pithos /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Metadata | grep xesam:title | cut -d: -f3;;
    album)
        qdbus org.mpris.MediaPlayer2.pithos /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Metadata | grep xesam:album | cut -d: -f3;;
    station)
        qdbus net.sourceforge.radiotray /net/sourceforge/radiotray net.sourceforge.radiotray.getCurrentRadio;;
    esac
}

#rplay)      RadioTray "$@"; exit 0;;


case "$1" in
# Now Playing Info
clementine) Clementine "$@"; exit 0;;
    pithos)     Pithos "$@"; exit 0;;
esac
exit 0;
