#!/bin/bash
cd /usr/share/ultimate_edition/
./conky-builder.sh
