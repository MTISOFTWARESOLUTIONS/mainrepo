#!/usr/bin/env python

import gtk, webkit, os
import sys

print 'Number of arguments:', len(sys.argv), 'arguments.'
print 'Argument List:', str(sys.argv)
for arg in sys.argv[1:]:
        print arg
        ediMsg = 'file://' + arg
	print ediMsg

class ExampleEditor(gtk.Window):
  def __init__(self):
    gtk.Window.__init__(self)
    self.set_title(arg)
    self.connect("destroy", gtk.main_quit)
    self.resize(500, 500)
    self.filename = ediMsg
    self.statusIcon = gtk.StatusIcon()
    self.statusIcon.set_from_file("/usr/share/ultamatix/ultamatix.png")
    self.statusIcon.set_visible(True)

    #self.window.set_icon_from_file('/usr/share/ultamatix/ultamatix.png')

    self.editor = webkit.WebView()
    self.editor.open ( 'http://www.google.com' )

    scroll = gtk.ScrolledWindow()
    entry = gtk.GtkEntry()

    scroll.add(self.editor)
    entry.add(self.editor)
    scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)

    self.ui = self.generate_ui()
    self.add_accel_group(self.ui.get_accel_group())
    self.toolbar1 = self.ui.get_widget("/toolbar_main")
    self.menubar = self.ui.get_widget("/menubar_main")

    self.layout = gtk.VBox()
    self.layout.pack_start(self.menubar, False)
    self.layout.pack_start(self.toolbar1, False)
    self.layout.pack_start(scroll, True, True)
    self.add(self.layout)

  def generate_ui(self):
    ui_def = """
    <ui>
      <menubar name="menubar_main">
        <menu action="menuFile">
          <menuitem action="new" />
          <menuitem action="open" />
          <menuitem action="save" />
          <menuitem action="exit" />
        </menu>
        <menu action="menuHelp">
          <menuitem action="help" />
          <menuitem action="about" />
        </menu>
      </menubar>
      <toolbar name="toolbar_main">
        <toolitem action="back" />
        <toolitem action="forward" />
        <separator />
      </toolbar>
    </ui>
    """

    actions = gtk.ActionGroup("Actions")
    actions.add_actions([
      ("menuFile", None, "_File"),
      ("menuEdit", None, "_Edit"),
      ("menuInsert", None, "_Insert"),
      ("menuFormat", None, "_Format"),
      ("menuHelp", None, "_Help"),

      ("back", gtk.STOCK_GO_BACK, "_Back", None, None, self.on_action),
      ("forward", gtk.STOCK_GO_FORWARD, "_Forward", None, None, self.on_action),

      ("open", gtk.STOCK_OPEN, "_Open", None, None, self.on_open),
      ("save", gtk.STOCK_SAVE, "_Save", None, None, self.on_save),

      ("help", gtk.STOCK_HELP, "_Help", None, None, self.on_help),
      ("about", gtk.STOCK_ABOUT, "_About", None, None, self.on_about),
    ])

    ui = gtk.UIManager()
    ui.insert_action_group(actions)
    ui.add_ui_from_string(ui_def)
    return ui

  def on_action(self, action):
    self.editor.execute_script(
      "document.execCommand('%s', false, false);" % action.get_name())

  def on_paste(self, action):
    self.editor.paste_clipboard()

  def on_help(self, action):
    self.editor.open ("http://google.com/")

  def on_exit(self, action):
    self.connect("destroy", gtk.main_quit)

  def on_about(self, action):
    """ Opens the About Dialog. """
    dialog = gtk.AboutDialog()
    dialog.set_name('Quick Browser')
    # VERSIONNUMBER
    dialog.set_version('2.0')
    dialog.set_comments('Quick Browser')
    dialog.set_website('http://ultimateedition.info')
    dialog.run()
    dialog.destroy()

    entry = gtk.Entry()
    dialog.vbox.pack_start(entry)
    dialog.show_all()

    if dialog.run() == gtk.RESPONSE_OK:
      fn = dialog.get_filename()
      if os.path.exists(fn):
        self.editor.execute_script(
          "document.execCommand('insertImage', null, '%s');" % fn)
    dialog.destroy()

  def on_open(self, action):
    dialog = gtk.FileChooserDialog("Select an HTML file", self, gtk.FILE_CHOOSER_ACTION_OPEN,
      (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))

    if dialog.run() == gtk.RESPONSE_OK:
      fn = dialog.get_filename()
      if os.path.exists(fn):
        self.filename = fn
        with open(fn) as fd:
          self.editor.load_html_string(fd.read(), "file:///")
    dialog.destroy()

  def on_save(self, action):
    if self.filename:
      with open(self.filename) as fd: fd.write(self.get_html())
    else:
      dialog = gtk.FileChooserDialog("Select an HTML file", self, gtk.FILE_CHOOSER_ACTION_SAVE,
        (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_SAVE, gtk.RESPONSE_OK))

      if dialog.run() == gtk.RESPONSE_OK:
        self.filename = dialog.get_filename()
        with open(self.filename, "w+") as fd: fd.write(self.get_html())
      dialog.destroy()

  def get_html(self):
    self.editor.execute_script("document.title=document.documentElement.innerHTML;")
    return self.editor.get_main_frame().get_title()

e = ExampleEditor()
e.show_all()
gtk.main()
