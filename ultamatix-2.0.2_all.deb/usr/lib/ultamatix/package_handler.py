import apt

cache = apt.Cache()
pkg = cache['python-apt'] # Access the Package object for python-apt
print 'python-apt is trusted:', pkg.candidate.origins[0].trusted

# Mark python-apt for install
pkg.markInstall()

print 'python-apt is marked for install:', pkg.markedInstall

print 'python-apt is (summary):', pkg.candidate.summary

# Now, really install it
cache.commit()

