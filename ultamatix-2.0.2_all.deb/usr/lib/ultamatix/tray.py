import gtk, pango
import sys
class TrayIcon(object):
    __icon = False
    __mapped = False
    __tips = ''
    __menu = None
    def __init__(self, window):
        try: import egg.trayicon as trayicon
        except ImportError:
            try: import _trayicon as trayicon
            except: return
        self.__icon = self.icon = trayicon.TrayIcon("automatix_tray")
        try: p = gtk.gdk.pixbuf_new_from_file_at_size("/usr/share/ultamatix/pixmaps/ultimate_icon.png", 16, 16)
        except:
            p = gtk.gdk.pixbuf_new_from_file_at_size("/usr/share/ultamatix/pixmaps/ultimate_icon.png", 16, 16)
        img = gtk.Image()
        if p: img.set_from_pixbuf(p)
        eb = gtk.EventBox(); eb.add(img)
        self.icon.add(eb)
        self.windowevent = self.icon.connect('button-press-event', self.__button, window)
        #window.connect('delete-event', self.__window_delete)
        self.myTip = gtk.Tooltips()
        print "TRAY ICON CREATED"
        self.icon.show_all()
    def set_window(self,window):
       self.icon.disconnect(self.windowevent)
       self.windowevent = self.icon.connect('button-press-event', self.__button, window)
    def set_label(self,text):
    	self.myTip.set_tip(self.icon, text)
    def __window_delete(self, window, event):
       if self.enabled:
         self.__hide_window(window)
         return True
    def __show_window(self, window):
        try: window.move(*window.__position)
        except AttributeError: pass
        window.show()
    def __hide_window(self, window):
        window.__position = window.get_position()
        window.hide()
    def __enabled(self):
        return (self.__icon  and self.__mapped and
                self.__icon.get_property('visible'))
    enabled = property(__enabled)
    def __button(self, icon, event, window):
        if event.button == 1:
            if window.get_property('visible'): self.__hide_window(window)
            else: self.__show_window(window)
    def destroy(self):
        if self.__icon: self.__icon.destroy()
        if self.__menu: self.__menu.destroy()
