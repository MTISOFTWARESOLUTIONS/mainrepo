#!/usr/bin/env python
import sys
#import wx
#from wx.animate import *
#from pygame import mixer
#mixer.init()
#mixer.music.load('/usr/share/ultamatix/conf/discipline.mp3')
if len(sys.argv) < 2:
	print "You can't run Ultamatix like this try '/usr/bin/ultamatix' instead"
	sys.exit()
sys.path += ["/usr/lib/ultamatix"]
from resin_config import *
sys.path += [axConf.locations['modules']]
ultamatix_version = "Ultamatix: 2.0.1"
resin_version = "Resin version: 3.2.8"

if '-d' in sys.argv or '--debug' in sys.argv:
	print "Ultamatix is running in debug mode all errors no matter how small will be displayed."
	print ultamatix_version
	print resin_version
if '-v' in sys.argv or '--version' in sys.argv:
	print ultamatix_version
	print resin_version
	sys.exit()
if '-e' in sys.argv or '--dumplog' in sys.argv:
	try:
		dump = open("%s/.ultamatix/activity.log"%axUser.home).readlines()
	except:
		print "No activity log was found"
		sys.exit()
	for d in dump:
		print d,
	sys.exit()
if '-h' in sys.argv  or '--help' in sys.argv:
	print """
	Ultamatix 2.0.2
	possible commands...
	-v	--version		dump version info
	-e	--dumplog		dump activity log
	-h	--help			this help message
	-d      --debug mode		pushes python into debug mode
	"""
	sys.exit()

from startup import *

#        mixer.music.play(-1)
start = startUp()
from main_interface import *
main = main_ui()
gtk.main()
