import wave, ossaudiodev

sound = wave.open('/usr/share/ultamatix/conf/saw.wav' , 'rb')

fr = sound.getframerate()
nc = sound.getnchannels()
nf = sound.getnframes()
data = sound.readframes(nf)
sound.close()
## take to the player for program 5
dsp = ossaudiodev.open('/dev/dsp','w')
dsp.setparameters(ossaudiodev.AFMT_S16_NE, nc, fr)
dsp.write(data)
dsp.close()

