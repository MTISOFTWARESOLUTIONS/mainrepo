#!/bin/bash
# title			:conky-builder.sh
# description		:Builds a Conky skeleton based on hardware detected.
# author		:Glenn Cady <theemahn@ultimateedition.info>
# date			:04/21/2013
# version		:1.21
# usage			:./conky-builder.sh
# notes			:See change-log below for further information.
# bash_version		:4.2.8(1)-release
# ============================================================================
# Change-log:

# 1.0	initial public release

# 1.1	internal release

# 1.2	internal release

# 1.3	internal release

# 1.4	Added distribution detection, added resolution detection
#	to set fonts and sizes.

# 1.05	Added version compliance for deb based releases
#	Added better networking detection / wireless support.
#	Added memory output to compare against pae based kernels.
#	Added 800 X 600 support, how did I miss this resolution?
#	Added initial support for Ultimate Player (dynamically)
#	Added support for all network interface detection / Active.
#	Never have I seen this implementation.  I try to think outside of
#	the box please report issues.
#	Added support for Ultimate Edition 2.6.4 and 3.1 detection
#	Added dynamic Wireless support.
#	Added CPU Temp / Fan speeds also dynamic.

# 1.06	Added Radio tray to the mix
#	Initiated the anti-cron job mode of thinking, execi can be executed
#	w/o the need for a cron job.  Let's base this on the end users CPU.
#	Added no Internet means do not propagate - includes wireless.
#	The same across the board when I am done and hopefully will not
#	require a cron job.

# 1.07	Initiated real-time information, across issues I have set forth.
#	Set CPU Temp to display info real-time based on end users processor. A
#	single core CPU will not be updated as fast as a quad for example
#	please see timeslices in my code.
#	Set fan speed accordingly as above.

# 1.08	Split the Conky builder for Ultimate Player info
#	May integrate the info as a function later.
#	Added progress bar for current playing track.
#	All info for Ultimate Player is now real-time.

# 1.09	First initial deb based release

# 1.10	Internal release for Ultimate Edition 3.01
#	Fixed improper spacing when closing Ultimate Player.

# 1.11	Fixed improper CPU detection on some Intel based processors.
#	Began writing weather location / detection via users IP address.
#	the above will be a fairly difficult procedure. Query to a API driven
#	Geo-positioning map to obtain location based on zip code, once obtained
#	a query to another API   driven site noaa.gov.  Will require no user
#	interaction.

# 1.12	Added support for 12.04 precise (Ultimate Edition 3.4 & 3.5) based releases.

# 1.13	Corrected colors to be only 1 color for now, easier reading on most wallpapers.
#	Will eventually write it to detect theme and set colors appropriately.

# 1.14	Added GPU and Main-board temp detection routines.
#	Added initial dual monitor detection / setup routine.
#	Added ppp0 network detection to the mix, thanks Seedo Eldho Paul
#	Added Hard-disk temperature detection, this was a rough one to sift
#	though and match with the drives.

# 1.15	Internal release to Ultimate Edition 3.5
#	Fixed Garbling of GPU / CPU Temp
#	Adjusted Colors to coincide with Ultimate Edition 3.5 Theme
#	Removed Lua usage. Thanks Mr. Breeg and Goliath for testing

# 1.16	Set colors in CLI so errors etc. Stand out.
#	Added additional distribution detection routines (debugging currently)
#	No sense in having to re-write conky builder every-time I build a new OS.
#	Display album art if Ultimate Player is Jamming.
#	Major code clean up, I am a slob ;)
#	Updated distribution logo
#	Mass updates to resolution detection routine. Simple once again becomes
#	complex thanks to addition of the artwork from Ultimate Player.

# 1.17	Adjusted output of information to comply with screen width.
#	Detection of USB drives - no output of temperature.
#	Detection of NAS drives - no output of temperature.
#	Added 1280 X 800 resolution; thanks, tanmay.01
#	Adjusted Temp detection routines let's not waste space.
#	Dual monitors now displayed @0 pixels from the top.
#	Took debugging into my own hands on temps.
#	Smartly built displaying of temp info into columns.
#	If no Swap. No Swap info reported in Conky. Save precious screen resources.
#	Reduced top processes to 3.
#	Adjusted diskio activity and network activity bars to coincide in length.

# 1.18	Added NFS based Network Attached Storage detection.

# 1.19	Ran code-clean and bashdepends on this script, dependencies adjusted.

# 1.20	Added Video card detection
#	Changed colors to coincide with colors of Ultimate Edition 3.4 series
#	Added Raid array detection

# 1.21	Point to point protocol issue gone?  Thanks again Seedo
# 	Implemented enhanced color / bar graphs.
#	Added 1366 X 768 resolution, thanks again Seedo

# =============== End Change-log ===================== #
#
# Set Base, hi-light & header color. Feel free to adjust colors in hex and font
# to your liking.
# Please Note: Graph width and font size are based on detected screen resolution.

GRAPHWIDTH=180
FONTSIZE=6
#BASE='${color #ffffff}${font Liberation:style=normal:pixelsize='$FONTSIZE'}'
#HILIGHT='${color #ffffff}${font Liberation:style=normal:pixelsize='$FONTSIZE'}'
#HEADER='${color ffffff}${font Liberation:style=Bold:pixelsize='$FONTSIZE'}'
#BAR='${color #ffffff}'

############### You Should not have to edit anything below #############

#Set hard-coded variables

VERSION='1.21'
UPSCRIPT='~.config/Ultimate-Player/UP.sh'
declare -i Dual

# Set ASCII Esc sequences so terminal colors stand out
txtblk='\e[0;30m'	# Black - Regular
txtred='\e[0;31m'	# Red
txtgrn='\e[0;32m'	# Green
txtylw='\e[0;33m'	# Yellow
txtblu='\e[0;34m'	# Blue
txtpur='\e[0;35m'	# Purple
txtcyn='\e[0;36m'	# Cyan
txtwht='\e[0;37m'	# White
bldblk='\e[1;30m'	# Black - Bold
bldred='\e[1;31m'	# Red
bldgrn='\e[1;32m'	# Green
bldylw='\e[1;33m'	# Yellow
bldblu='\e[1;34m'	# Blue
bldpur='\e[1;35m'	# Purple
bldcyn='\e[1;36m'	# Cyan
bldwht='\e[1;37m'	# White
unkblk='\e[4;30m'	# Black - Underline
undred='\e[4;31m'	# Red
undgrn='\e[4;32m'	# Green
undylw='\e[4;33m'	# Yellow
undblu='\e[4;34m'	# Blue
undpur='\e[4;35m'	# Purple
undcyn='\e[4;36m'	# Cyan
undwht='\e[4;37m'	# White
bakblk='\e[40m'		# Black - Background
bakred='\e[41m'		# Red
badgrn='\e[42m'		# Green
bakylw='\e[43m'		# Yellow
bakblu='\e[44m'		# Blue
bakpur='\e[45m'		# Purple
bakcyn='\e[46m'		# Cyan
bakwht='\e[47m'		# White
txtrst='\e[0m'		# Text Reset

# drop headers
echo -e "${bldwht}Ultimate Edition Conky builder version "$VERSION
echo -e "${undwht}Please report errors / issues to TheeMahn <TheeMahn@ultimateedition.info>${txtrst}"

# Set default Operating System in case of failure
OS='Ultimate Edition'

#Detect code-base / Distribution
OS=$(lsb_release -i | sed -n 's/^Distributor ID:[ \t]*\(.*\)/\1/p')
DISTREL=$(lsb_release -r | sed -n 's/^Release:[ \t]*\(.*\)/\1/p')
DISTDESC=$(lsb_release -d | sed -n 's/^Description:[ \t]*\(.*\)/\1/p')
CODEBASE=`cat /etc/lsb-release | grep 'DISTRIB_CODENAME=' | sed 's/DISTRIB_CODENAME=//g'`

echo "Codebase detected: "$CODEBASE

echo -e "${undgrn}Release debugging info:${txtrst}${bldred}"
echo $OS
echo $DISTREL
echo $DISTDESC
echo -e "${bldgrn}=======================${txtrst}"
# detect if release is odd or even.
EVENODD=`dpkg -l | grep kubuntu-desktop`

if [[ $EVENODD != "" ]]; then
	echo "Kubuntu base: detected - odd number release"
else
	echo "Kubuntu base not detected - even number release"
fi


echo -n "Distro detected: "
#TESTING ABOVE
DISTRO=$OS" "$DISTREL
OS=$DISTRO
echo $DISTRO
#case "$CODEBASE" in
#precise)
#   if [[ $EVENODD != "" ]]; then
#  OS=$OS" 3.5"
#   else
#  OS=$OS" 3.4"
#   fi
#   echo $OS ;;
#oneiric)
#   if [[ $EVENODD != "" ]]; then
#  OS=$OS" 3.3"
#   else
#  OS=$OS" 3.2"
#   fi
#   echo $OS ;;
#natty)
#   if [[ $EVENODD != "" ]]; then
#  OS=$OS" 3.1"
#   else
#  OS=$OS" 3.01"
#   fi
#   echo $OS ;;
#maverick)
#   if [[ $EVENODD != "" ]]; then
#  OS=$OS" 2.9"
#   else
#  OS=$OS" 2.8"
#   fi
#   echo $OS ;;
#lucid)
#   if [[ $EVENODD != "" ]]; then
#  OS=$OS" 2.7"
#   else
#  OS=$OS" 2.6.6"
#   fi
#   echo $OS ;;#

#*)  echo "Unknown O/S using $CODEBASE"
#esac

# Attempt to advance the script.  No sense having the user edit this script
# if we can obtain the information without user intervention.
res=`xrandr -q | grep 'current' | cut -d"," -f2 | sed 's/current//g' | sed 's/ //g'`

# set default in case user has an unknown resolution. Better too small then too
# large
GRAPHWIDTH=320 #size of box in pixels
FONTSIZE=8 #default font size
SZE=64
DUAL=0
echo "Detected current resolution:" $res

case "$res" in
	3840x1200)
	# Tested known good
	DUAL=1
	AHW=76
	AARTY=76
	GRAPHWIDTH=440
	FONTSIZE=12
	echo "Dual monitors detected. Taking full advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	3840x1080)
	# Tested known good
	DUAL=1
	AHW=88
	AARTY=98
	GRAPHWIDTH=640
	FONTSIZE=16
	echo "Dual monitors detected. Taking advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	3200x1200)
	DUAL=1
	AHW=88
	AARTY=98
	GRAPHWIDTH=640
	FONTSIZE=16
	echo "Dual monitors detected. Taking advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	3200x1024)
	# Tested known good
	DUAL=1
	AHW=90
	AARTY=80
	GRAPHWIDTH=520
	FONTSIZE=14
	echo "Dual monitors detected. Taking advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	3360x900)
	# Tested known good
	DUAL=1
	AHW=78
	AARTY=74
	GRAPHWIDTH=480
	FONTSIZE=12
	echo "Dual monitors detected. Taking advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	3200x960)
	# Tested known good
	DUAL=1
	AHW=78
	AARTY=74
	GRAPHWIDTH=480
	FONTSIZE=12
	echo "Dual monitors detected. Taking advantage of extra screen resources."
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1920x1200)
	# Tested; known Good.
	AHW=84
	AARTY=84
	GRAPHWIDTH=600
	FONTSIZE=14
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1920x1080)
	# Tested; known Good.
	AHW=84
	AARTY=84
	GRAPHWIDTH=600
	FONTSIZE=14
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1600x1200)
	# Tested; known Good.
	AHW=84
	AARTY=84
	GRAPHWIDTH=550
	FONTSIZE=14
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1680x1050)
	# Tested; known Good.
	AHW=84
	AARTY=84
	GRAPHWIDTH=550
	FONTSIZE=14
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1440x900)
	# Tested known good
	AHW=75
	AARTY=70
	GRAPHWIDTH=420
	FONTSIZE=11
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1400x1050)
	# unknown
	AHW=75
	AARTY=70
	GRAPHWIDTH=420
	FONTSIZE=11
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1366x768)
	# Tested known good
	AHW=75
	AARTY=70
	GRAPHWIDTH=420
	FONTSIZE=11
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1280x1024)
	# Tested known good
	AHW=75
	AARTY=71
	GRAPHWIDTH=400
	FONTSIZE=11
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1280x960)
	# Tested known good
	AHW=75
	AARTY=71
	GRAPHWIDTH=400
	FONTSIZE=11
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1280x720)
	# Tested known good
	AHW=64
	AARTY=56
	GRAPHWIDTH=340
	FONTSIZE=9
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1152x864)
	# Tested known good
	AHW=64
	AARTY=56
	GRAPHWIDTH=340
	FONTSIZE=9
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	1024x768)
	# Tested known good
	AHW=64
	AARTY=56
	GRAPHWIDTH=340
	FONTSIZE=9
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	800x600)
	# Tested known good
	AHW=52
	AARTY=44
	GRAPHWIDTH=260
	FONTSIZE=7
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	832x624)
	# Tested known good
	AHW=52
	AARTY=48
	GRAPHWIDTH=300
	FONTSIZE=8
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	720x400)
	GRAPHWIDTH=180
	FONTSIZE=6
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	640x480)
	GRAPHWIDTH=180
	FONTSIZE=6
	echo "Setting font size to $FONTSIZE and graph width to $GRAPHWIDTH" ;;
	*)
	GRAPHWIDTH=320
	FONTSIZE=12
	echo -e "${bldred}Resolution not programmed defaulting, please report detected resolution\n above to <theemahn@ultimateedition.info>${txtrst}" ;;
esac

#set Base, hi-light color & header please adjust colors in hex and font to your liking
#http://simple.wikipedia.org/wiki/List_of_colors
BASE='${color #FFBF00}${font Liberation:style=normal:pixelsize='$FONTSIZE'}' #Atomic Tangerine
HILIGHT='${color #ffff00}${font Liberation:style=normal:pixelsize='$FONTSIZE'}' #Yellow
HEADER='${color #00ffff}${font Liberation:style=Bold:pixelsize='$FONTSIZE'}' #Cyan
BAR='${color #ffffff}' #White

############### You Should not have to edit anything below #############

#Calculate v offset based on Fonts / pixelsize
VOFF=$((FONTSIZE+6))
ALEFT=$((FONTSIZE/4))
INDENT=$((FONTSIZE/2))
BARZ=$((GRAPHWIDTH/2))
BOFFSET=$((FONTSIZE/3))
TICON=$((FONTSIZE/5))
BPER=$((GRAPHWIDTH/100*75))
SBAR=$((GRAPHWIDTH/100*20))
LOGO=$((FONTSIZE*2))
SZE=$((LOGO*2))
LOGO=`expr $LOGO - 5`
BPER=`expr $BPER - 10`
AARTX=`expr $GRAPHWIDTH - $AHW`
#echo "Logo Size: $SZE"

#Get CPU model
RESONATION=`cat /proc/cpuinfo | grep 'cpu MHz' | sed -e 's/.*: //' | uniq`
PROC=`cat /proc/cpuinfo | grep 'model name' | sed -e 's/.*: //' | uniq`
echo "Processor:" $PROC "resonating at $RESONATION Mhz"

#check Architecture set 32 bit default
ARCHITECTURE='32 Bit'

#
# Check for x86_64 (Test 1) - some O/S's use the -i switch
#
if [ "`uname -i|grep x86_64`" == "x86_64" ]; then
	ARCHITECTURE='64 Bit'
fi

#
# Check for x86_64 (Test 2) - some OSs (ie. Gentoo) return Processor manufacturer
#rather than architecture with "uname -i"
#
if [ "`uname -a|grep x86_64`" != "" ]; then
	ARCHITECTURE='64 Bit'
fi

# Report to user
echo $ARCHITECTURE 'O/S detected.'

# Count number of processor cores
CORES=1 #Set default
CORES=`cat /proc/cpuinfo | grep "processor" | sed '/model/d' | wc -l`

# Lets's not choke the end users CPU if they have limited resources.
TIMESLICES=`expr 12 / $CORES`

# Report findings
echo $CORES "CPU core(s) Detected."
echo 'Update interval set: '$TIMESLICES
cat /proc/meminfo | grep 'MemTotal'
SWAPTOTAL=`cat /proc/meminfo | grep "SwapTotal" | sed 's/ //g' | cut -d ':' -f2 | cut -d 'k' -f1`

#SWAPTOTAL=1024 #Set for debugging purposes
if [[ $SWAPTOTAL == "0" ]]; then
	echo "No Swap detected; not going to populate Conky."
else
	echo "Swap Total: $SWAPTOTAL"
fi

#Advance network detection to perfection scan all interfaces:
ls /sys/class/net/ > /tmp/ifaces.txt
if test -f /tmp/ifaces.txt
	then
	echo -e "${undgrn}Network interfaces detected${txtrst}"
	cat /tmp/ifaces.txt
	echo -e "${undgrn}Scanning for active${txtrst}"
	cat /tmp/ifaces.txt | while read FILE
	do
		target=$(echo "$FILE" | sed -e "s/ /_/")
		echo -n "Interface $FILE: "
		ACT=$(cat /sys/class/net/$FILE/operstate)
		echo $ACT
		if [[ $ACT == 'up' ]]; then
			ACTIVE=$FILE
			echo $FILE > /tmp/tmpo.txt
			echo -e "${undgrn}Active Network${txtrst}: "$ACTIVE
		fi
	done

	# Current Seedo work...  If the folder exists most likely it is the
	# active connection set it as such.  Point to Point Protocol evidently
	# does not do states. up / down etc.

	if [[ -d "/sys/class/net/ppp0/" && $ACTIVE == "" ]]; then
		ACTIVE="ppp0"
		echo $ACTIVE > /tmp/tmpo.txt
	fi
else
	echo 'No Active network.'
fi
if test -f /tmp/tmpo.txt
	then
	ACTIVE=$(cat /tmp/tmpo.txt)
else
	ACTIVE='No Inet'
fi
echo -en "${undgrn}Active Monitoring Connection${txtrst}: "
echo $ACTIVE
if test -f /tmp/tmpo.txt
	then
	WIRELESS=$(cat /tmp/tmpo.txt|grep 'wlan')
fi
if [[ $WIRELESS != '' ]]
	then
	wlan='up'
fi

#Clean up.
if test -f /tmp/ifaces.txt
	then
	rm /tmp/ifaces.txt
fi
if test -f /tmp/tmpo.txt
	then
	rm /tmp/tmpo.txt
fi
#Detect "Active" network and propigate Network Xfer bar
#ACTIVE=`ifconfig | grep -B 1 inet | head -1 | awk '{print $1}'`
#Wireless?
#wlan=$(cat /sys/class/net/wlan0/operstate)
#enet=$(cat /sys/class/net/eth0/operstate)

#Hardline?
#if [[ $enet == 'up' ]]; then
#$ACTIVE='eth0'
#fi

#Wireless
#if [[ $wlan == 'up' ]]; then
#ACTIVE='wlan0'
#fi

#Dual monitors?
if [[ $DUAL == 0 ]]; then
	GAPX=15
	GAPY=30
else
	GAPX=15
	GAPY=0
fi

#Create conky skelaton
echo '#Use XFT?
use_xft yes
xftfont Liberation:style=normal:pixelsize='$FONTSIZE'
xftalpha 0.8
text_buffer_size 2048

# Update interval in seconds
update_interval 1

# This is the number of times Conky will update before quitting.
# Set to zero to run forever.
total_run_times 0

# Create own window instead of using desktop (required in nautilus)
own_window yes
own_window_transparent yes
own_window_type override
#own_window_hints undecorated,below,sticky,skip_taskbar,skip_pager

# Use double buffering (reduces flicker, may not work for everyone)
double_buffer yes

# Minimum size of text area -adjust if you would like to user smaller fonts etc.
minimum_size '$GRAPHWIDTH' 0
maximum_width '$GRAPHWIDTH'
max_specials 1024
max_user_text 16384
default_bar_size '$BPER' 5

# Draw shades?
draw_shades no
default_color 0a3f6d #ffffff
# Draw outlines?
draw_outline no

# Draw borders around text
draw_borders no

# Stippled borders?
stippled_borders 0

# border width
border_width 1

# Text alignment, other possible values are commented
#alignment top_left
alignment top_right
#alignment bottom_left
#alignment bottom_right

# Gap between borders of screen and text
# same thing as passing -x at command line
gap_x '$GAPX'
gap_y '$GAPY'

#Default weather to fahrenheit, please change the below if you prefer celcius.
temperature_unit fahrenheit

# -- Lua Load -- # - removed in conky builder > 1.15
#lua_load ~/.draw_bg.lua
#lua_draw_hook_pre draw_bg

# -- Album art fix -- #
imlib_cache_size 0
' > ~/.conkyrc

echo 'TEXT' >> ~/.conkyrc

# Begin system info output
echo '${image /usr/share/ultimate_edition/logo.png -p '$BARZ','$LOGO' -s '$SZE'x'$SZE'}'$HEADER'SYSTEM ${hr 2 }'$BASE >> ~/.conkyrc
echo '${alignr}'$OS' - ${alignr}$kernel '$ARCHITECTURE >> ~/.conkyrc
echo '${alignr}'$USER'@$nodename' >> ~/.conkyrc
echo -n '${goto '$INDENT'}${voffset '$TICON'}${font StyleBats:pixelsize='$FONTSIZE'}k${font}${voffset -'$ALEFT'}${goto '$VOFF'}${font}Processes: '$HILIGHT'$processes' >> ~/.conkyrc
echo $BASE'${alignr}${voffset '$TICON'}${font StyleBats:pixelsize='$FONTSIZE'}q${font}Uptime: '$HILIGHT'${uptime}' >> ~/.conkyrc

# Ultimate Player running? In not; no info is populated on Conky.
echo '${if_running ultimate-player}'$HEADER'ULTIMATE PLAYER ${hr 2 }'$BASE'${image ~/.config/Ultimate-Player/Current.art -p '$AARTX','$AARTY' -s '$AHW'x'$AHW'}' >> ~/.conkyrc
echo '${voffset 2}${font Poky:pixelsize='$FONTSIZE'}k${font}${goto '$VOFF'}${voffset -'$ALEFT'}${font}Artist: '$HILIGHT'${execi '$TIMESLICES' .config/Ultimate-Player/UP.sh artist}' >> ~/.conkyrc
echo $BASE'${font}${voffset 2}${font Poky:pixelsize='$FONTSIZE'}k${font}${goto '$VOFF'}${voffset -'$ALEFT'}${font}Title: '$HILIGHT'${execi '$TIMESLICES' .config/Ultimate-Player/UP.sh title}' >> ~/.conkyrc
echo $BASE'${font}${voffset 2}${font Poky:pixelsize='$FONTSIZE'}k${font}${goto '$VOFF'}${voffset -'$ALEFT'}${font}Album: '$HILIGHT'${execi '$TIMESLICES' .config/Ultimate-Player/UP.sh album}' >> ~/.conkyrc
echo '${execibar '$TIMESLICES' .config/Ultimate-Player/UP.sh progress}${else}${endif}' >> ~/.conkyrc

# Radio Tray running? In not; no info is populated on Conky.
echo '${if_running radiotray}'$HEADER'RADIO TRAY ${hr 2 }'$BASE >> ~/.conkyrc
echo '${voffset 2}${font Poky:pixelsize='$FONTSIZE'}k${goto '$VOFF'}${voffset -'$ALEFT'}${font}Playing: '$HILIGHT '${execi '$TIMESLICES' .config/Ultimate-Player/UP.sh rplay}' >> ~/.conkyrc
echo $BASE'${font StyleBats:pixelsize='$FONTSIZE'}q${font}${voffset -'$ALEFT'}${goto '$VOFF'}${voffset -'$ALEFT'}${font}Station: '$HILIGHT '${execi '$TIMESLICES' .config/Ultimate-Player/UP.sh rstation}${else}${voffset -23}${endif}' >> ~/.conkyrc

#Core(s) info
echo $HEADER'CPU${hr 2 }'$BASE >> ~/.conkyrc
echo '${goto '$INDENT'}${voffset '$TICON'}${font Stylebats:pixelsize='$FONTSIZE'}A${font}${voffset -'$ALEFT'}${goto '$VOFF'}${font}${goto '$VOFF'}'$PROC'
${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}A${voffset -'$ALEFT'}${goto '$VOFF'}${font}CPU Usage: '$HILIGHT' ${freq}MHz X '$CORES'${alignr}${cpu cpu0}% '$BAR' ${cpubar cpu0 '$INDENT','$SBAR'}' >> ~/.conkyrc

# Hit sensors to see if temperature(s) are detected / reported.
echo -e "${bldgrn}SCANNING FOR SENSOR(S)...${txtrst}"
echo -e "${undgrn}OBJECT\t\tDISCOVERED\t\tSENSOR${txtrst}"
CPUTEMP=$(sensors -f | grep -m 1 "CPU Temperature" | cut -d: -f2 | sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1)
GPUTEMP=$(sensors -f | grep -m 1 "temp1" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1)
VIDCARD=$(glxinfo | grep -m 1 'renderer string' | sed 's/OpenGL renderer string: //g')
MBTEMP=$(sensors -f | grep -m 1 "MB Temp" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1)
FANSPEED=$(sensors -f | grep -m 1 "CPU Fan Speed"| cut -d: -f2 | sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1)
EVEN=0
echo -n $BASE >> ~/.conkyrc
#CPUTEMP="" #set for debugging purposes
if [[ $CPUTEMP != '' ]]
	then
	echo -n '${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}A${voffset -'$ALEFT'}${goto '$VOFF'}${font}CPU Temp: '$HILIGHT >> ~/.conkyrc
	echo -n '${execi '$TIMESLICES' sensors -f | grep -m 1 "CPU Temperature"|cut -d: -f2|sed "s/ //g"|sed "s/+//g" | cut -d"(" -f1}${alignr}' >> ~/.conkyrc
	EVEN=1
	echo -e "CPU\t\tYES\t\t\t$CPUTEMP"
else
	echo -e "CPU\t\tNO\t\t\t${bldred}N/A${txtrst}"
	EVEN=0
fi
#FANSPEED="" #set for debugging purposes

if [[ $FANSPEED != '' ]]
	then
	if [[ $EVEN == "0" ]]; then
		echo -n $BASE'${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}F${voffset -'$ALEFT'}${goto '$VOFF'}${font}Fan speed: '$HILIGHT >> ~/.conkyrc
		echo -n '${execi '$TIMESLICES' sensors -f| grep -m -1 "CPU Fan Speed"|cut -d: -f2|sed "s/ //g"|sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
		echo -e "FANSPEED\tYES\t\t\t$FANSPEED"
		EVEN=1 # Set switch so next detected can be set on the same line.
	else
		echo -n $BASE'Fan Speed: '$HILIGHT >> ~/.conkyrc
		echo '${execi '$TIMESLICES' sensors -f | grep -m 1 "CPU Fan Speed"|cut -d: -f2|sed "s/ //g"|sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
		echo -e "FANSPEED\tYES\t\t\t$FANSPEED"
		EVEN=0 # End of the line doe no use the -n with echo above.
	fi
else
	echo -e "FANSPEED\t\t\t\t${bldred}NOT DETECTED${txtrst}"
fi

#GPUTEMP="" #set for debugging purposes
#GPU TEMP?
if [[ $GPUTEMP != '' ]]
	then
	if [[ $EVEN == "0" ]]; then
		if [[ $VIDCARD == '' ]]; then
			echo -n $BASE'${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}Y${voffset -'$ALEFT'}${goto '$VOFF'}${font}GPU Temp: '$HILIGHT >> ~/.conkyrc
			echo -n '${execi '$TIMESLICES' sensors -f | grep -m 1 "temp1" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
			echo -e "GPU\t\tYES\t\t\t$GPUTEMP"
			EVEN=1
		else
			echo -n $BASE'${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}Y${voffset -'$ALEFT'}${goto '$VOFF'}${font}'$VIDCARD': '$HILIGHT >> ~/.conkyrc
			echo -n '${execi '$TIMESLICES' sensors -f | grep -m 1 "temp1" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
			echo -e "GPU\t\tYES\t\t\t$GPUTEMP"
			EVEN=1
		fi
	else
		if [[ $VIDCARD == '' ]]; then
			echo -n '${font}${alignr}GPU Temp: '$HILIGHT >> ~/.conkyrc
			echo '${execi '$TIMESLICES' sensors -f | grep -m 1 "temp1" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
			echo -e "GPU\t\tYES\t\t\t$GPUTEMP"
			EVEN=0
		else
			echo -n '${font}${alignr}'$VIDCARD': '$HILIGHT >> ~/.conkyrc
			echo '${execi '$TIMESLICES' sensors -f | grep -m 1 "temp1" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
			echo -e $VIDCARD"\t\tYES\t\t\t$GPUTEMP"
			EVEN=0
		fi

	fi
else
	echo -e "GPU\t\tNO\t\t\t${bldred}N/A${txtrst}"
fi

#MBTEMP="" #set for debugging purposes
#Main-board Temp?
if [[ $MBTEMP != '' ]]
	then
	if [[ $EVEN == "0" ]]; then
		echo -n $BASE'${goto '$INDENT'}${font StyleBats:pixelsize='$FONTSIZE'}F${voffset -'$ALEFT'}${goto '$VOFF'}${font}MB Temp: '$HILIGHT >> ~/.conkyrc
		echo '${execi '$TIMESLICES' sensors -f|grep -m 1 "MB Temp" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
		echo -e "MAIN-BOARD\tYES\t\t\t$MBTEMP"
		EVEN=1
	else
		echo -n $BASE'${font}${alignr}MB Temp: '$HILIGHT >> ~/.conkyrc
		echo '${execi '$TIMESLICES' sensors -f|grep -m 1 "MB Temp" | cut -d: -f2| sed "s/ //g" | sed "s/+//g" | cut -d"(" -f1}' >> ~/.conkyrc
		echo -e "MAIN-BOARD\tYES\t\t\t$MBTEMP"
		EVEN=0
	fi
else
	echo -e "MAIN-BOARD\tNO\t\t\t${bldred}N/A${txtrst}"
fi

# Close out TEMPS with a line.
echo $HEADER'${hr 2}'$BASE >> ~/.conkyrc

# Create a cpubar for each core
COUNTER=0
while [  $COUNTER != $CORES ]; do
	let COUNTER=COUNTER+1
	echo '${goto '$INDENT'}${voffset '$TICON'}${font StyleBats:pixelsize='$FONTSIZE'}A${font}${voffset -'$ALEFT'}${goto '$VOFF'}${font}Core '$COUNTER':' $HILIGHT'${cpu cpu'$COUNTER'}% '$BAR'${alignr}${cpubar cpu'$COUNTER' '$INDENT','$BPER'}'$BASE >> ~/.conkyrc
done

# Output total memory / usage.
echo $HEADER'RAM${hr 2 }'$BASE >> ~/.conkyrc
echo -n $BASE'${voffset 2}${font VariShapes Solid:pixelsize='$FONTSIZE'}N'$BASE'Useage: '$HILIGHT'$mem / $memmax ${alignr}'$HILIGHT'$memperc% '$BAR'${membar '$INDENT','$SBAR'}' >> ~/.conkyrc

# Swap check - no sense in display the info if the user does not have any swap.
if [[ $SWAPTOTAL != "0" ]]; then
	echo '' >> ~/.conkyrc
	echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Stylebats:pixelsize='$FONTSIZE'}j${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE'Swap: '$HILIGHT'$swap/$swapmax${alignr}$swapperc% '$BAR'${swapbar '$INDENT','$SBAR'}' >> ~/.conkyrc
else
	echo '' >> ~/.conkyrc
fi

# Top Processes / Ram Hogs
echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}a${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE'${goto '$VOFF'}Highest: ${alignr}CPU     RAM
${goto '$VOFF'}${voffset -5.5}'$HILIGHT'${hr 2}
'$HILIGHT'${voffset -1}${goto '$VOFF'}${top name 1}${alignr}${top cpu 1}  ${top mem 1}
${goto '$VOFF'}${top name 2}${alignr}${top cpu 2}  ${top mem 2}
${goto '$VOFF'}${top name 3}${alignr}${top cpu 3}  ${top mem 3}' >> ~/.conkyrc

# File-system(s)
echo $HEADER'FILESYSTEM(s)${hr 2 }'$BASE >> ~/.conkyrc
echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}Y${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE'Disk I/O: '$HILIGHT'${diskio}${alignr}'$BAR'${diskiograph '$LOGO','$BPER'}'>> ~/.conkyrc

# Detect hard disks & create a bar for each mount point provide info to end user
# Step one crack out the whip on the SCSI (Sata) channel.

# HDSIZE=0 future implementation
# TSPACE=0 future implementation

# display the information to end user in pretty columns
echo -en "${undgrn}"
printf '%-15s %-24s %s\n' \
DEVICE MOUNTPOINT HDTEMP
echo -en "${txtrst}"
awk '/dev\/sd/ {print $1}' /etc/mtab | sort | while read line
do
	MOUNTPOINT=$(df $line | awk '{print $6}' | sed '1d')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	echo $MOUNTPOINT >> /tmp/mpoint.txt
	if [ $STRIPPED = "/" ]; then
		STRIPPED="Root"
	fi

	HDDTMP=$(echo $line | sed 's/[0-9]*//g')
	#HDSIZE=$(udisks --show-info $line | egrep "^[[:space:]]*size" | awk '{print $2}')
	HDTEMP=$(hddtemp $line --unit=f --numeric)
	SMART=$(echo $HDTEMP | grep -v "S.M.A.R.T. not available")
	SENSOR=$(echo $HDTEMP | grep -v "have a temperature sensor")
	#TSPACE=$(expr ${TSPACE} + ${HDSIZE})

	# If Temperature was detected populate Conky as well display info to user.
	if [[ $SMART != "" &&  $SENSOR != "" ]]; then
		printf '%-15s %-24s %s\n' \
		"$line" "$STRIPPED" "$HDTEMP°F"
		echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${hddtemp '$HDDTMP'}°F | ${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
	else
		printf '%-15s %-24s %s\n' \
		"$line" "$STRIPPED" N/A°F
		echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
	fi
done;

# Hard disks continued. HDA/B Etc.?
awk '/dev\/hd/ {print $1}' /etc/mtab | sort | while read line
do
	MOUNTPOINT=$(df $line | awk '{print $6}' | sed '1d')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	echo $MOUNTPOINT >> /tmp/mpoint.txt

	if [[ $STRIPPED == "/" ]]; then
		STRIPPED="Root"
	fi

	# Hard Drive / USB / Partition: Set temp readings if it applies as per drive."
	HDDTMP=$(echo $line | sed 's/[0-9]*//g')
	HDSIZE=$(udisks --show-info $line | egrep "^[[:space:]]*size" | awk '{print $2}')
	HDTEMP=$(hddtemp $line --unit=f --numeric)
	SMART=$(echo $HDTEMP | grep -v "S.M.A.R.T. not available")
	SENSOR=$(echo $HDTEMP | grep -v "have a temperature sensor")
	#TSPACE=$(expr ${TSPACE} + ${HDSIZE})

	# If Temperature was detected populate Conky as well display info to user.
	if [[ $SMART != "" &&  $SENSOR != "" ]]; then
		printf '%-15s %-24s %s\n' \
		"$line" "$STRIPPED" "$HDTEMP°F"
		echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${hddtemp '$HDDTMP'}°F | ${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
	else
		printf '%-15s %-24s %s\n' \
		"$line" "$STRIPPED" N/A°F
		echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
	fi
done;

# Hard disks continued. RAID MD0 Etc.?
awk '/dev\/md/ {print $1}' /etc/mtab | sort | while read line
do
	MOUNTPOINT=$(df $line | awk '{print $6}' | sed '1d')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	echo $MOUNTPOINT >> /tmp/mpoint.txt

	if [[ $STRIPPED == "/" ]]; then
		STRIPPED="Root"
	fi

	# Hard Drive / USB / Partition: Set temp readings if it applies as per drive."
	HDDTMP=$(echo $line | sed 's/[0-9]*//g')
	HDSIZE=$(udisks --show-info $line | egrep "^[[:space:]]*size" | awk '{print $2}')
	#TSPACE=$(expr ${TSPACE} + ${HDSIZE})

	# If Temperature was detected populate Conky as well display info to user.
		printf '%-15s %-24s %s\n' \
		"$line" "$STRIPPED" N/A°F
		echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc

done;


# Step 2 NFS based NAS
# or better yet write a function & eliminate a large chunk of code.
df | awk '/:/ {print $1}' /etc/mtab | while read line
do
	MOUNTPOINT=$(df | grep $line | awk '{ print $6 }')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	echo $MOUNTPOINT >> /tmp/mpoint.txt
	fout=$(echo $line | cut -d":" -f1)
	printf '%-15s %-24s %s\n' \
	"$fout" "$STRIPPED" "N/A°F"
	HDDTMP=$(echo $line | sed 's/[0-9]*//g')
	echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$fout'): '$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
done;


# Step 3 Burners
awk '/dev\/sr/ {print $1}' /etc/mtab | sort | while read line
do
	MOUNTPOINT=$(df $line | awk '{print $6}' | sed '1d')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	if [ $STRIPPED = "/" ]; then
		STRIPPED="Root"
	fi
	printf '%-15s %-24s %s\n' \
	"$line" "$STRIPPED" N/A°F
	HDDTMP=$(echo $line | sed 's/[0-9]*//g')
	echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
done;

# Step 4 - Why stop there snatch up NAS(s) drives.
awk '/\/\// {print $2}' /etc/mtab | sort | while read line
do
	MOUNTPOINT=$(df $line | awk '{print $8}' | sed '1d')
	STRIPPED=$(echo $MOUNTPOINT | sed 's/\/media\///g')
	if [ $STRIPPED = "/" ]; then
		STRIPPED="Root"
	fi
	printf '%-15s %-24s %s\n' \
	"$line" "$STRIPPED" N/A°F
	# No temp detection via network do not populate TEMP.
	echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}H${font}${voffset -'$ALEFT'}${goto '$VOFF'}'$BASE$STRIPPED' ('$line'):${tab}'$HILIGHT'${fs_free '$MOUNTPOINT'} / ${fs_size '$MOUNTPOINT'}${alignr}${fs_used_perc '$MOUNTPOINT'}% '$BAR'${fs_bar '$INDENT','$SBAR' '$MOUNTPOINT'}'$BASE >> ~/.conkyrc
done;

# Network re-visit...
if [[ $ACTIVE != 'No Inet' ]];then
	echo $HEADER'ACTIVE NETWORK: '$ACTIVE'${hr 2 }'$BASE >> ~/.conkyrc >> ~/.conkyrc

	# Propagate networking information based on active connection
	echo '${voffset 2}${font VariShapes Solid:pixelsize='$FONTSIZE'}q${goto '$VOFF'}${voffset -'$ALEFT'}'$BASE'Up: '$HILIGHT'${upspeed '$ACTIVE'} '$BAR'${alignr}${upspeedgraph '$ACTIVE' '$LOGO','$BPER' ${font} '$BAR' }' >> ~/.conkyrc
	#${voffset -24}${goto '$VOFF'}Total: ${totalup '$ACTIVE'}
	echo $BASE'${voffset -'$LOGO'}${goto '$VOFF'}'$BASE'Total: '$HILIGHT'${totalup '$ACTIVE'}' >> ~/.conkyrc
	echo $BASE'${voffset -'$ALEFT'}${font VariShapes Solid:pixelsize='$FONTSIZE'}Q${goto '$VOFF'}${voffset -'$ALEFT'}'$BASE'Down: '$HILIGHT'${downspeed '$ACTIVE'} '$BAR'${alignr}${downspeedgraph '$ACTIVE' '$LOGO','$BPER' ${font} '$BAR'}' >> ~/.conkyrc
	echo $BASE'${font}${voffset -'$LOGO'}${goto '$VOFF'}Total: '$HILIGHT'${totaldown '$ACTIVE'}'$BASE >> ~/.conkyrc

	# Provide wireless info if user is using wireless actively.
	if [[ $wlan == 'up' ]]; then

		#Wireless header
		echo $HEADER'Wireless: '$ACTIVE'${hr 2 }' >> ~/.conkyrc

		# ACCESS POINT
		echo '${voffset 2}${font VariShapes Solid:pixelsize='$FONTSIZE'}-${goto '$VOFF'}${voffset -'$ALEFT'}${font}Wireless Access Point: '$HILIGHT'${alignr}${wireless_essid '$ACTIVE'}' >> ~/.conkyrc

		# Connection strength / signal
		echo '${font}${voffset 2}${font Stylebats:pixelsize='$FONTSIZE'}Z${goto '$VOFF'}${voffset -'$ALEFT'}${font}Connection strength: '$HILIGHT'${alignr}${wireless_link_qual_perc '$ACTIVE'}%' >> ~/.conkyrc

		# Connection speed
		echo '${font}${voffset 2}${font Stylebats:pixelsize='$FONTSIZE'}C${goto '$VOFF'}${voffset -'$ALEFT'}${font}Connection max throughput: '$HILIGHT'${alignr}${wireless_bitrate '$ACTIVE'}' >> ~/.conkyrc
	fi

	# echo $HEADER'${voffset -'$ALEFT'}${hr 2}' >> ~/.conkyrc

	# Provide general connection info
	echo -n '${font}${voffset -'$ALEFT'}${font Poky:pixelsize='$FONTSIZE'}w${goto '$VOFF'}${voffset -'$ALEFT'}${font}Local IP: '$HILIGHT'${addr '$ACTIVE'}${alignr}' >> ~/.conkyrc
	echo $BASE'${font}${voffset 2}${font Stylebats:pixelsize='$FONTSIZE'}M${font}TCP Connections: '$HILIGHT'${tcp_portmon 1 65535 count}' >> ~/.conkyrc
fi
echo $HEADER'${voffset -'$ALEFT'}${hr 2}' >> ~/.conkyrc
# Close out with a thin line at the bottom & the Date / Time
echo $BASE'${goto '$INDENT'}${voffset '$TICON'}${font Poky:pixelsize='$FONTSIZE'}d${voffset -'$ALEFT'}${goto '$VOFF'}'$HEADER'${goto '$VOFF'}${alignc}${time %H:%M}, ${time %A %d %B}' >> ~/.conkyrc
echo $HEADER'${voffset -'$ALEFT'}${hr 2}' >> ~/.conkyrc
#echo $HEADER'${voffset -'$ALEFT'}${hr 2}' >> ~/.conkyrc
exit 0 # make sure we exit graciously, we want to add to boot-up with && to allow
# other processes to continue.  No sense in being a hog and slowing boot time.
